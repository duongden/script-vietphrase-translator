/**
 * editor.js — Dictionary editor
 */

const ext = globalThis.browser ?? globalThis.chrome;

function runtimeSendMessage(message, callback) {
  try {
    if (callback) {
      const result = ext.runtime.sendMessage(message);
      if (result && typeof result.then === 'function') {
        result.then(
          value => callback(value),
          () => callback(undefined)
        );
      } else {
        ext.runtime.sendMessage(message, callback);
      }
      return;
    }
    return ext.runtime.sendMessage(message);
  } catch (_error) {
    if (callback) callback(undefined);
    else return Promise.resolve(undefined);
  }
}

const DB_NAME = 'VietphraseDB';
const STORE   = 'dicts';
const PAGE    = 100;
let _idb = null;

function fixVietnamese(text) {
  return (text ?? '').toString().normalize('NFC');
}

async function openDB() {
  if (_idb) return _idb;
  return new Promise((res, rej) => {
    const req = indexedDB.open(DB_NAME, 1);
    req.onsuccess = e => { _idb = e.target.result; res(_idb); };
    req.onerror   = e => rej(e.target.error);
  });
}

async function idbGet(key) {
  const db = await openDB();
  return new Promise((res, rej) => {
    const req = db.transaction(STORE).objectStore(STORE).get(key);
    req.onsuccess = e => res(e.target.result ? e.target.result.data : null);
    req.onerror   = e => rej(e.target.error);
  });
}

const bgMsg = m => new Promise(res => runtimeSendMessage(m, res));

function mdIcon(name, cls = 'mi') {
  const paths = {
    search: '<path d="M15.5 14h-.79l-.28-.27a6 6 0 1 0-.71.71l.27.28v.79L20 21.5 21.5 20zM10 15a5 5 0 1 1 0-10 5 5 0 0 1 0 10"/>',
    inbox: '<path d="M19 3H4.99C3.88 3 3 3.89 3 5v14c0 1.1.89 2 1.99 2H19c1.1 0 2-.9 2-2V5c0-1.11-.9-2-2-2m0 12h-4c0 1.1-.9 2-2 2s-2-.9-2-2H7V5h12z"/>',
    edit: '<path d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75zm17.71-10.04a1.003 1.003 0 0 0 0-1.42L18.21 3.29a1.003 1.003 0 0 0-1.42 0l-1.96 1.96 3.75 3.75z"/>',
    save: '<path d="M17 3H5a2 2 0 0 0-2 2v14h18V7zm-5 14a3 3 0 1 1 0-6 3 3 0 0 1 0 6M6 8V5h8v3z"/>',
    restore: '<path d="M12 5V2L8 6l4 4V7c2.76 0 5 2.24 5 5a5 5 0 1 1-9.9-1H5.08A7 7 0 1 0 12 5"/>',
    delete: '<path d="M6 19c0 1.1.9 2 2 2h8a2 2 0 0 0 2-2V7H6zm3.46-7.12 1.41-1.41L12 11.59l1.12-1.12 1.41 1.41L13.41 13l1.12 1.12-1.41 1.41L12 14.41l-1.12 1.12-1.41-1.41L10.59 13zM15.5 4l-1-1h-5l-1 1H5v2h14V4z"/>',
    progress: '<path d="M12 2a10 10 0 1 0 10 10h-2a8 8 0 1 1-8-8z"/>'
  };
  return `<svg class="${cls}" viewBox="0 0 24 24" aria-hidden="true">${paths[name] || ''}</svg>`;
}

// ── State ──────────────────────────────────────────────
let currentDict   = 'VP';
let currentMode   = 'base'; // base = imported dict only, edit = user edits/deletes only
let allEntries    = [];
let filtered      = [];
let currentPage   = 1;
let currentFilter = 'all';
let searchQuery   = '';
let editCache     = { VP: {}, Names: {} };
let deletedCache  = { VP: new Set(), Names: new Set() };

function esc(s) {
  return fixVietnamese(s)
    .replace(/&/g,'&amp;').replace(/</g,'&lt;')
    .replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

// ── Load entries from IndexedDB ────────────────────────
async function loadEntries(dict) {
  const key     = dict === 'Names' ? 'Names'        : 'VP';
  const editKey = dict === 'Names' ? 'editNames'    : 'editVP';
  const delKey  = dict === 'Names' ? 'deletedNames' : 'deletedVP';

  const [base, edits, deleted] = await Promise.all([
    idbGet(key), idbGet(editKey), idbGet(delKey)
  ]);

  editCache[dict]    = edits   || {};
  deletedCache[dict] = new Set(deleted || []);

  const baseObj = Object.fromEntries(Object.entries(base || {}).map(([k, v]) => [fixVietnamese(k), fixVietnamese(v)]));
  const editObj = Object.fromEntries(Object.entries(edits || {}).map(([k, v]) => [fixVietnamese(k), fixVietnamese(v)]));
  const delSet  = deletedCache[dict];
  const entries = [];

  if (currentMode === 'base') {
    for (const [han, viet] of Object.entries(baseObj)) {
      entries.push({ han, viet, status: 'original', origViet: null });
    }
  } else {
    for (const [han, viet] of Object.entries(editObj)) {
      entries.push({
        han,
        viet,
        status: han in baseObj ? 'edited' : 'new',
        origViet: han in baseObj ? baseObj[han] : null
      });
    }
    for (const han of delSet) {
      entries.push({
        han,
        viet: baseObj[han] || '',
        status: 'deleted',
        origViet: baseObj[han] || null
      });
    }
  }

  const order = { new: 0, edited: 1, deleted: 2, original: 3 };
  entries.sort((a, b) => {
    const d = (order[a.status] ?? 3) - (order[b.status] ?? 3);
    return d !== 0 ? d : a.han.localeCompare(b.han);
  });

  allEntries = entries;
}

// ── Filter + render ────────────────────────────────────
function applyFilters() {
  let rows = allEntries;
  if (currentMode === 'edit') {
    if      (currentFilter === 'edited')  rows = rows.filter(e => e.status === 'edited' || e.status === 'new');
    else if (currentFilter === 'deleted') rows = rows.filter(e => e.status === 'deleted');
    else if (currentFilter === 'changed') rows = rows.filter(e => e.status !== 'original');
  }

  const q = searchQuery.trim().toLowerCase();
  if (q) rows = rows.filter(e => e.han.includes(q) || e.viet.toLowerCase().includes(q));

  filtered    = rows;
  currentPage = 1;
  renderTable();
  renderPagination();
  updateHeaderStats();
}

function renderTable() {
  const tbody = document.getElementById('tbody');
  const start = (currentPage - 1) * PAGE;
  const page  = filtered.slice(start, start + PAGE);

  if (!page.length) {
    const emptyText = currentMode === 'edit'
      ? 'Chưa có từ nào được chỉnh sửa trong tab này.'
      : 'Không có dữ liệu. Hãy tải từ điển lên từ Popup.';
    tbody.innerHTML = `<tr><td colspan="4">
      <div class="empty">
        <div class="empty-icon">${searchQuery ? mdIcon('search', 'mi mi-lg') : mdIcon('inbox', 'mi mi-lg')}</div>
        <div class="empty-text">${searchQuery ? 'Không tìm thấy kết quả' : emptyText}</div>
      </div></td></tr>`;
    return;
  }

  const BADGES = {
    edited:   '<span class="badge badge-edited">Đã sửa</span>',
    deleted:  '<span class="badge badge-deleted">Đã xóa</span>',
    new:      '<span class="badge badge-new">Mới</span>',
    original: ''
  };

  tbody.innerHTML = page.map((entry, rel) => {
    const pageIdx = start + rel;  // index trong filtered[]
    const isDel   = entry.status === 'deleted';
    const badge   = BADGES[entry.status] || '';
    const hint    = (entry.origViet && entry.status === 'edited')
      ? `<div class="orig-hint">Gốc: ${esc(entry.origViet)}</div>` : '';

    const actionBtns = isDel
      ? `<div class="act-btns">
           <button class="ico-btn btn-restore" data-action="restore" data-idx="${pageIdx}" title="Khôi phục">${mdIcon('restore')}<span>Khôi phục</span></button>
         </div>`
      : `<div class="act-btns">
           <button class="ico-btn btn-edit"   data-action="edit"   data-idx="${pageIdx}" title="Sửa">${mdIcon('edit')}</button>
           <button class="ico-btn btn-save"   data-action="save"   data-idx="${pageIdx}" title="Lưu" style="display:none">${mdIcon('save')}</button>
           <button class="ico-btn btn-cancel" data-action="cancel" data-idx="${pageIdx}" title="Hủy" style="display:none">${mdIcon('restore')}</button>
           ${entry.status !== 'original'
             ? `<button class="ico-btn btn-restore" data-action="restore" data-idx="${pageIdx}" title="Khôi phục gốc">${mdIcon('restore')}</button>`
             : ''}
           <button class="ico-btn btn-del" data-action="delete" data-idx="${pageIdx}" title="Xóa">${mdIcon('delete')}</button>
         </div>`;

    return `<tr data-idx="${pageIdx}">
      <td class="col-han">${esc(entry.han)}</td>
      <td class="col-viet">
        <span class="viet-display">${esc(entry.viet)}</span>
        <div class="edit-wrap" style="display:none">
          <input class="edit-input" type="text" value="${esc(entry.viet)}" data-idx="${pageIdx}">
          <div class="case-bar">
            <button class="case-btn" data-case="lower"  data-idx="${pageIdx}" title="Viết thường: tiệt giáo"><span class="case-code">aa</span><span class="case-hint">thường</span></button>
            <button class="case-btn" data-case="first"  data-idx="${pageIdx}" title="Hoa chữ đầu: Tiệt giáo"><span class="case-code">Aa</span><span class="case-hint">đầu 1</span></button>
            <button class="case-btn" data-case="second" data-idx="${pageIdx}" title="Hoa từ thứ hai: tiệt Giáo"><span class="case-code">aA</span><span class="case-hint">đầu 2</span></button>
            <button class="case-btn" data-case="all"    data-idx="${pageIdx}" title="Hoa đầu mỗi từ: Tiệt Giáo"><span class="case-code">AA</span><span class="case-hint">tất cả</span></button>
          </div>
        </div>
        ${hint}
      </td>
      <td class="col-status">${badge}</td>
      <td class="col-action">${actionBtns}</td>
    </tr>`;
  }).join('');
}

function renderPagination() {
  const total = filtered.length;
  const pages = Math.ceil(total / PAGE) || 1;
  document.getElementById('pagInfo').textContent =
    `${total.toLocaleString()} từ · trang ${currentPage} / ${pages}`;

  const btnsEl = document.getElementById('pagBtns');
  if (pages <= 1) { btnsEl.innerHTML = ''; return; }

  let html = '';
  const btn  = (p, lbl) =>
    `<button class="page-btn${p === currentPage ? ' active' : ''}" data-page="${p}">${lbl}</button>`;
  const dots = () => '<span class="page-dots">…</span>';

  html += btn(1, '«');
  html += btn(Math.max(1, currentPage - 1), '‹');
  const s = Math.max(1, currentPage - 3), e = Math.min(pages, currentPage + 3);
  if (s > 1) html += dots();
  for (let p = s; p <= e; p++) html += btn(p, p);
  if (e < pages) html += dots();
  html += btn(Math.min(pages, currentPage + 1), '›');
  html += btn(pages, '»');

  btnsEl.innerHTML = html;
}

function gotoPage(p) {
  const pages = Math.ceil(filtered.length / PAGE) || 1;
  currentPage = Math.max(1, Math.min(pages, p));
  renderTable();
  renderPagination();
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

function updateHeaderStats() {
  const eObj = editCache[currentDict]    || {};
  const dSet = deletedCache[currentDict] || new Set();
  document.getElementById('hTotalCount').textContent = allEntries.length.toLocaleString();
  document.getElementById('hEditCount').textContent  = currentMode === 'edit' ? Object.keys(eObj).length : 0;
  document.getElementById('hDelCount').textContent   = currentMode === 'edit' ? dSet.size : 0;
}

// ── Get row by filtered index ──────────────────────────
function getRow(idx) {
  return document.querySelector(`tr[data-idx="${idx}"]`);
}

// ── Case-transform helpers ─────────────────────────────
function capWord(w) {
  if (!w) return w;
  const chars = [...w];
  return chars[0].toUpperCase() + chars.slice(1).join('');
}
const caseTransforms = {
  lower:  s => s.toLowerCase(),
  first:  s => { const w = s.toLowerCase().split(' '); if (w.length) w[0] = capWord(w[0]); return w.join(' '); },
  second: s => { const w = s.toLowerCase().split(' '); if (w.length >= 2) w[1] = capWord(w[1]); return w.join(' '); },
  all:    s => s.toLowerCase().split(' ').map(capWord).join(' '),
};

function applyEditorCase(caseType, idx) {
  const row = getRow(idx);
  if (!row) return;
  const inp = row.querySelector('.edit-input');
  if (!inp || !inp.value.trim()) return;
  inp.value = caseTransforms[caseType](inp.value);
  // Highlight active case button
  row.querySelectorAll('.case-btn').forEach(b => {
    const active = b.dataset.case === caseType;
    b.classList.toggle('case-btn-active', active);
  });
  inp.focus();
}

async function applyDictionaryChangesToTabs() {
  await bgMsg({ action: 'reloadDicts' });
  await bgMsg({ action: 'reloadAllTabs' });
}

// ── Inline row editing ─────────────────────────────────
function startEdit(idx) {
  const row = getRow(idx);
  if (!row) return;
  const entry = filtered[idx];
  row.querySelector('.viet-display').style.display = 'none';
  row.querySelector('.edit-wrap').style.display    = '';
  row.querySelector('[data-action=edit]').style.display   = 'none';
  row.querySelector('[data-action=save]').style.display   = '';
  row.querySelector('[data-action=cancel]').style.display = '';
  const inp = row.querySelector('.edit-input');
  inp.focus(); inp.select();
  // Auto-detect & highlight current case
  if (entry) {
    const v = entry.viet;
    const words = v.trim().split(' ');
    const isCapWord = w => w && [...w][0] === [...w][0].toUpperCase() && [...w][0] !== [...w][0].toLowerCase();
    let detected = null;
    if (words.every(w => !isCapWord(w))) detected = 'lower';
    else if (words.length > 1 && words.every(isCapWord)) detected = 'all';
    else if (words.length >= 1 && isCapWord(words[0]) && (words.length < 2 || !isCapWord(words[1]))) detected = 'first';
    else if (words.length >= 2 && !isCapWord(words[0]) && isCapWord(words[1])) detected = 'second';
    if (detected) {
      row.querySelectorAll('.case-btn').forEach(b =>
        b.classList.toggle('case-btn-active', b.dataset.case === detected));
    }
  }
}

function cancelEdit(idx) {
  const row   = getRow(idx);
  const entry = filtered[idx];
  if (!row || !entry) return;
  row.querySelector('.edit-input').value           = entry.viet;
  row.querySelector('.viet-display').style.display = '';
  row.querySelector('.edit-wrap').style.display    = 'none';
  row.querySelector('[data-action=edit]').style.display   = '';
  row.querySelector('[data-action=save]').style.display   = 'none';
  row.querySelector('[data-action=cancel]').style.display = 'none';
  row.querySelectorAll('.case-btn').forEach(b => b.classList.remove('case-btn-active'));
}

async function doSave(idx) {
  const row   = getRow(idx);
  const entry = filtered[idx];
  if (!row || !entry) return;
  const newViet = fixVietnamese(row.querySelector('.edit-input').value).trim();
  if (!newViet) { showToast('Vui lòng nhập nghĩa tiếng Việt', 'err'); return; }

  const saveBtn = row.querySelector('[data-action=save]');
  saveBtn.innerHTML = mdIcon('progress'); saveBtn.disabled = true;

  const res = await bgMsg({ action: 'editEntry', dict: currentDict, han: entry.han, viet: newViet });
  if (res?.success) {
    showToast('Đã lưu');
    await refresh();
    await applyDictionaryChangesToTabs();
  } else {
    showToast('Lỗi: ' + (res?.error || 'unknown'), 'err');
    saveBtn.innerHTML = mdIcon('save'); saveBtn.disabled = false;
  }
}

async function doDelete(idx) {
  const entry = filtered[idx];
  if (!entry) return;
  const isNewEdit = currentMode === 'edit' && entry.status === 'new';
  const promptText = isNewEdit
    ? `Xóa mục mới "${entry.han}" khỏi danh sách chỉnh sửa?`
    : `Xóa "${entry.han}" khỏi từ điển?\n(Có thể khôi phục bằng nút khôi phục)`;
  if (!confirm(promptText)) return;
  const action = isNewEdit ? 'restoreEntry' : 'deleteEntry';
  const res = await bgMsg({ action, dict: currentDict, han: entry.han });
  if (res?.success) { showToast('Đã xóa'); await refresh(); await applyDictionaryChangesToTabs(); }
  else showToast('Lỗi: ' + (res?.error || 'unknown'), 'err');
}

async function doRestore(idx) {
  const entry = filtered[idx];
  if (!entry) return;
  if (!confirm(`Khôi phục "${entry.han}" về giá trị gốc?`)) return;
  const res = await bgMsg({ action: 'restoreEntry', dict: currentDict, han: entry.han });
  if (res?.success) { showToast('Đã khôi phục'); await refresh(); await applyDictionaryChangesToTabs(); }
  else showToast('Lỗi: ' + (res?.error || 'unknown'), 'err');
}

// ── Add new entry ──────────────────────────────────────
async function addNew() {
  const han  = fixVietnamese(document.getElementById('addHan').value).trim();
  const viet = fixVietnamese(document.getElementById('addViet').value).trim();
  if (!han || !viet) { showToast('Vui lòng nhập đủ chữ Hán và nghĩa', 'err'); return; }
  const res = await bgMsg({ action: 'editEntry', dict: currentDict, han, viet });
  if (res?.success) {
    document.getElementById('addHan').value  = '';
    document.getElementById('addViet').value = '';
    showToast(`Đã thêm "${han}"`);
    await refresh();
    await applyDictionaryChangesToTabs();
  } else {
    showToast('Lỗi: ' + (res?.error || 'unknown'), 'err');
  }
}

// ── Export ─────────────────────────────────────────────
async function doExport(dict) {
  const res = await bgMsg({ action: 'exportEdits', dict });
  if (!res?.text && res?.text !== '') { showToast('Lỗi export', 'err'); return; }
  if (!res.text.trim()) { showToast('Chưa có mục nào được sửa/thêm', 'err'); return; }
  const blob = new Blob([res.text], { type: 'text/plain;charset=utf-8' });
  const url  = URL.createObjectURL(blob);
  const a    = Object.assign(document.createElement('a'), { href: url, download: res.filename });
  a.click();
  URL.revokeObjectURL(url);
    showToast(`Đã xuất ${res.filename}`);
}

// ── Tab switch ────────────────────────────────────────
async function switchTab(dict, mode) {
  currentDict = dict;
  currentMode = mode;
  document.getElementById('exportBtn').textContent =
    `Xuất ${dict === 'VP' ? 'vietphrase-edit.txt' : 'names-edit.txt'}`;
  document.getElementById('exportBtn').style.display = mode === 'edit' ? '' : 'none';
  document.querySelector('.filter-btns').style.display = mode === 'edit' ? '' : 'none';
  document.querySelector('.add-bar').style.display = mode === 'edit' ? '' : 'none';
  searchQuery   = '';
  currentFilter = 'all';
  document.getElementById('searchInput').value = '';
  document.querySelectorAll('.filter-btn[data-filter]').forEach(b =>
    b.classList.toggle('active', b.dataset.filter === 'all'));
  await refresh();
}

// ── Refresh ────────────────────────────────────────────
async function refresh() {
  setLoading(true);
  await loadEntries(currentDict);
  applyFilters();
  setLoading(false);
}

// ── Toast ──────────────────────────────────────────────
let _toastTimer;
function showToast(msg, type = 'ok') {
  let t = document.getElementById('_editor_toast');
  if (!t) {
    t = document.createElement('div');
    t.id = '_editor_toast';
    Object.assign(t.style, {
      position: 'fixed', bottom: '24px', left: '50%',
      transform: 'translateX(-50%)',
      padding: '10px 22px', borderRadius: '8px',
      fontSize: '13px', fontWeight: '600',
      zIndex: '9999', pointerEvents: 'none',
      transition: 'opacity .25s', whiteSpace: 'nowrap'
    });
    document.body.appendChild(t);
  }
  t.textContent = fixVietnamese(msg);
  t.style.background = type === 'err' ? '#c53030' : '#38a169';
  t.style.color      = '#fff';
  t.style.opacity    = '1';
  clearTimeout(_toastTimer);
  _toastTimer = setTimeout(() => { t.style.opacity = '0'; }, 2500);
}

function setLoading(show) {
  document.getElementById('loading').style.display = show ? 'flex' : 'none';
}

// ═══════════════════════════════════════════════════════
// Event delegation — tbody (dict view)
// ═══════════════════════════════════════════════════════
function bindTbody() {
  const tbody = document.getElementById('tbody');

  tbody.addEventListener('click', e => {
    // Case-transform buttons
    const caseBtn = e.target.closest('.case-btn');
    if (caseBtn) {
      applyEditorCase(caseBtn.dataset.case, parseInt(caseBtn.dataset.idx));
      return;
    }
    // Row action buttons
    const btn = e.target.closest('[data-action]');
    if (!btn) return;
    const action = btn.dataset.action;
    const idx    = parseInt(btn.dataset.idx);
    switch (action) {
      case 'edit':    startEdit(idx);  break;
      case 'save':    doSave(idx);     break;
      case 'cancel':  cancelEdit(idx); break;
      case 'restore': doRestore(idx);  break;
      case 'delete':  doDelete(idx);   break;
    }
  });

  tbody.addEventListener('input', e => {
    const inp = e.target.closest('.edit-input');
    if (!inp) return;
    const row = inp.closest('tr');
    if (row) row.querySelectorAll('.case-btn').forEach(b => b.classList.remove('case-btn-active'));
  });

  tbody.addEventListener('keydown', e => {
    const inp = e.target.closest('.edit-input');
    if (!inp) return;
    const idx = parseInt(inp.dataset.idx);
    if (e.key === 'Enter')  { e.preventDefault(); doSave(idx); }
    if (e.key === 'Escape') { cancelEdit(idx); }
  });
}

// Pagination
function bindPagination() {
  document.getElementById('pagBtns').addEventListener('click', e => {
    const btn = e.target.closest('[data-page]');
    if (btn) gotoPage(parseInt(btn.dataset.page));
  });
}

// ═══════════════════════════════════════════════════════
// Init
// ═══════════════════════════════════════════════════════
document.addEventListener('DOMContentLoaded', async () => {
  setLoading(true);

  // ── Main view tabs ──
  document.querySelectorAll('.tab-btn[data-view]').forEach(btn =>
    btn.addEventListener('click', async () => {
      const view = btn.dataset.view;
      if (view === 'vp') await switchTab('VP', 'base');
      else if (view === 'names') await switchTab('Names', 'base');
      else if (view === 'vp-edit') await switchTab('VP', 'edit');
      else if (view === 'names-edit') await switchTab('Names', 'edit');
      document.querySelectorAll('.tab-btn[data-view]').forEach(b => b.classList.toggle('active', b === btn));
    }));

  // ── Search ──
  let searchTimer;
  document.getElementById('searchInput').addEventListener('input', function() {
    clearTimeout(searchTimer);
    searchTimer = setTimeout(() => { searchQuery = this.value; applyFilters(); }, 220);
  });

  // ── Filter buttons ──
  document.querySelectorAll('.filter-btn[data-filter]').forEach(btn =>
    btn.addEventListener('click', function() {
      document.querySelectorAll('.filter-btn[data-filter]').forEach(b => b.classList.remove('active'));
      this.classList.add('active');
      currentFilter = this.dataset.filter;
      applyFilters();
    }));

  // ── Export (dict view) ──
  document.getElementById('exportBtn').addEventListener('click', () => doExport(currentDict));

  // ── Add new ──
  document.getElementById('addBtn').addEventListener('click', addNew);
  document.getElementById('addViet').addEventListener('keydown', e => {
    if (e.key === 'Enter') addNew();
  });

  // ── Event delegation ──
  bindTbody();
  bindPagination();

  await switchTab('VP', 'base');
  setLoading(false);
});
