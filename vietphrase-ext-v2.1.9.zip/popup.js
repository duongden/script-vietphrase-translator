const ext = globalThis.browser ?? globalThis.chrome;

function runtimeSendMessage(message, callback) {
  try {
    if (callback) {
      const result = ext.runtime.sendMessage(message);
      if (result && typeof result.then === 'function') {
        result.then(
          value => callback(value),
          () => callback(undefined)
        );
      } else {
        ext.runtime.sendMessage(message, callback);
      }
      return;
    }
    return ext.runtime.sendMessage(message);
  } catch (_error) {
    if (callback) callback(undefined);
    else return Promise.resolve(undefined);
  }
}

const msg = m => new Promise(res => runtimeSendMessage(m, r => {
  void ext.runtime.lastError;
  res(r);
}));

function fixVietnamese(text) {
  return (text ?? '').toString().normalize('NFC');
}

function showAlert(text, type) {
  const el = document.getElementById('alertBox');
  el.textContent = fixVietnamese(text);
  el.className = 'alert ' + (type === 'ok' ? 'ok' : 'err');
  el.style.display = 'block';
  clearTimeout(el._t);
  el._t = setTimeout(() => { el.style.display = 'none'; }, 3500);
}

function fmtNum(n) {
  if (n >= 1000) return (n / 1000).toFixed(1) + 'k';
  return String(n);
}

function updateUI(status) {
  if (!status) return;
  const hasData = status.pa > 0 || status.vp > 0 || status.names > 0;
  document.getElementById('statsBox').style.display = hasData ? 'grid' : 'none';
  if (hasData) {
    document.getElementById('nPA').textContent    = fmtNum(status.pa);
    document.getElementById('nVP').textContent    = fmtNum(status.vp);
    document.getElementById('nNames').textContent = fmtNum(status.names);
  }
  const setStatus = (id, count) => {
    const el = document.getElementById(id);
    if (count > 0) { el.textContent = fmtNum(count) + ' từ'; el.className = 'd-status ok'; }
    else           { el.textContent = 'Chưa tải';            el.className = 'd-status'; }
  };
  setStatus('sPA',    status.pa);
  setStatus('sVP',    status.vp);
  setStatus('sNames', status.names);

  const info = document.getElementById('editInfo');
  if (info) {
    const parts = [];
    if (status.editVP    > 0) parts.push(`VP: +${status.editVP} sửa`);
    if (status.editNames > 0) parts.push(`Names: +${status.editNames} sửa`);
    if (status.deletedVP > 0) parts.push(`VP: ${status.deletedVP} xóa`);
    if (status.deletedNames > 0) parts.push(`Names: ${status.deletedNames} xóa`);
    if (parts.length) { info.textContent = parts.join(' · '); info.style.display = 'block'; }
    else info.style.display = 'none';
  }
}

function updateBadge(enable) {
  const badge = document.getElementById('badge');
  badge.textContent = enable ? 'Đang bật' : 'Đang tắt';
  badge.classList.toggle('is-on', !!enable);
}

async function loadStatus() {
  const status = await msg({ action: 'getDictStatus' });
  updateUI(status);

  const opts = await msg({ action: 'getOptions' });
  if (opts) {
    document.getElementById('cbEnable').checked   = opts.enable !== false;
    document.getElementById('cbNgoac').checked    = !!opts.ngoac;
    document.getElementById('cbMotnghia').checked = opts.motnghia !== false;
    document.getElementById('cbDichlieu').checked = opts.dichlieu !== false;
    document.getElementById('cbTransBtn').checked = opts.showTransBtn !== false;

    document.getElementById('cbHeightAuto').checked   = opts.heightauto !== false;
    document.getElementById('cbWidthAuto').checked    = !!opts.widthauto;
    document.getElementById('cbScaleAuto').checked    = opts.scaleauto !== false;
    document.getElementById('cbEnableAjax').checked   = !!opts.enableajax;
    document.getElementById('cbEnableScript').checked = opts.enablescript !== false;
    document.getElementById('numDelayMutation').value = opts.delayMutation ?? 200;
    document.getElementById('numDelayTrans').value    = opts.delayTrans    ?? 120;

    updateBadge(opts.enable !== false);
  }
}

// ── IndexedDB helpers — popup writes directly, bypassing message size limits ──
const _DB_NAME = 'VietphraseDB';
const _DB_VER  = 1;
const _STORE   = 'dicts';
let   _popupDb = null;

function _openDB() {
  if (_popupDb) return Promise.resolve(_popupDb);
  return new Promise((res, rej) => {
    const req = indexedDB.open(_DB_NAME, _DB_VER);
    req.onupgradeneeded = e => {
      const db = e.target.result;
      if (!db.objectStoreNames.contains(_STORE))
        db.createObjectStore(_STORE, { keyPath: 'name' });
    };
    req.onsuccess = e => { _popupDb = e.target.result; res(_popupDb); };
    req.onerror   = e => rej(e.target.error);
  });
}

function _dbSet(key, data) {
  return _openDB().then(db => new Promise((res, rej) => {
    const req = db.transaction(_STORE, 'readwrite').objectStore(_STORE).put({ name: key, data });
    req.onsuccess = () => res();
    req.onerror   = e => rej(e.target.error);
  }));
}

function _parseDict(text, mode) {
  const out = {};
  for (const raw of fixVietnamese(text).split(/\r?\n/)) {
    const line = raw.trim();
    if (!line || line.startsWith('//') || line.startsWith('#') || line.startsWith('=')) continue;
    const eq = line.indexOf('=');
    if (eq < 1) continue;
    const k = fixVietnamese(line.slice(0, eq)).trim();
    const v = fixVietnamese(line.slice(eq + 1)).trim();
    if (!k || !v) continue;
    if (mode === 'PA') {
      const chars = [...k];
      const allCJK = chars.every(ch => /[\u3400-\u4dbf\u4e00-\u9fff\uf900-\ufaff\u3007]/.test(ch));
      if (!allCJK || chars.length !== 1) continue;
    }
    out[k] = v;
  }
  return out;
}

async function handleUpload(file, dictKey) {
  if (!file) return;
  const sEl = document.getElementById({ PA: 'sPA', VP: 'sVP', Names: 'sNames' }[dictKey]);
  sEl.textContent = 'Đang phân tích...'; sEl.className = 'd-status loading';
  try {
    const text   = await file.text();
    const parsed = _parseDict(text, dictKey === 'PA' ? 'PA' : '');
    await _dbSet(dictKey, parsed);
    const res = await msg({ action: 'reloadDicts' });
    if (res?.success) {
      updateUI(res.status);
      const count = { PA: res.status.pa, VP: res.status.vp, Names: res.status.names }[dictKey];
      showAlert(`Đã tải ${dictKey}: ${count.toLocaleString()} từ`, 'ok');
    } else {
      sEl.textContent = 'Lỗi'; sEl.className = 'd-status err';
      showAlert('Lỗi: ' + (res?.error || 'unknown'));
    }
  } catch (err) {
    sEl.textContent = 'Lỗi'; sEl.className = 'd-status err';
    showAlert('Lỗi: ' + err.message);
  }
}

function clampNum(id, min, max, def) {
  const el = document.getElementById(id);
  let v = parseInt(el.value);
  if (isNaN(v) || v < min) v = def ?? min;
  if (v > max) v = max;
  el.value = v;
  return v;
}

function setSaveButtonState(label) {
  const markup = label === 'saved'
    ? 'Đã lưu'
    : '<span class="btn-content"><svg class="mi mi-sm" viewBox="0 0 24 24" aria-hidden="true"><path d="M17 3H5a2 2 0 0 0-2 2v14h18V7zm-5 14a3 3 0 1 1 0-6 3 3 0 0 1 0 6M6 8V5h8v3z"/></svg><span>Lưu cài đặt</span></span>';
  for (const id of ['btnSave', 'btnSaveSticky']) {
    const btn = document.getElementById(id);
    if (btn) btn.innerHTML = markup;
  }
}

async function saveOptions() {
  const opts = {
    enable:       document.getElementById('cbEnable').checked,
    ngoac:        document.getElementById('cbNgoac').checked,
    motnghia:     document.getElementById('cbMotnghia').checked,
    dichlieu:     document.getElementById('cbDichlieu').checked,
    showTransBtn: document.getElementById('cbTransBtn').checked,
    heightauto:    document.getElementById('cbHeightAuto').checked,
    widthauto:     document.getElementById('cbWidthAuto').checked,
    scaleauto:     document.getElementById('cbScaleAuto').checked,
    enableajax:    document.getElementById('cbEnableAjax').checked,
    enablescript:  document.getElementById('cbEnableScript').checked,
    delayMutation: clampNum('numDelayMutation', 20, 5000, 200),
    delayTrans:    clampNum('numDelayTrans',    30, 5000, 120),
  };
  const res = await msg({ action: 'setOptions', options: opts });
  if (res?.success) {
    updateBadge(opts.enable);
    setSaveButtonState('saved');
    setTimeout(() => setSaveButtonState('default'), 2000);
  }
}

document.addEventListener('DOMContentLoaded', () => {
  if (location.search.includes('tab=1')) document.body.classList.add('tab-mode');
  loadStatus();

  document.getElementById('fPA').onchange    = e => { handleUpload(e.target.files[0], 'PA');    e.target.value = ''; };
  document.getElementById('fVP').onchange    = e => { handleUpload(e.target.files[0], 'VP');    e.target.value = ''; };
  document.getElementById('fNames').onchange = e => { handleUpload(e.target.files[0], 'Names'); e.target.value = ''; };

  document.getElementById('btnReload').onclick = async () => {
    const btn = document.getElementById('btnReload');
    btn.innerHTML = 'Đang tải lại...'; btn.disabled = true;
    const res = await msg({ action: 'reloadDicts' });
    if (res?.success) {
      updateUI(res.status);
      await msg({ action: 'reloadAllTabs' });
      btn.innerHTML = 'Đã tải lại';
      setTimeout(() => {
        btn.innerHTML = '<span class="btn-content"><svg class="mi mi-sm" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 6V3L8 7l4 4V8c2.76 0 5 2.24 5 5a5 5 0 0 1-8.66 3.54l-1.42 1.42A7 7 0 1 0 12 6z"/></svg><span>Tải lại dict</span></span>';
        btn.disabled = false;
      }, 2000);
    } else {
      btn.innerHTML = '<span class="btn-content"><svg class="mi mi-sm" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 6V3L8 7l4 4V8c2.76 0 5 2.24 5 5a5 5 0 0 1-8.66 3.54l-1.42 1.42A7 7 0 1 0 12 6z"/></svg><span>Tải lại dict</span></span>';
      btn.disabled = false;
    }
  };

  document.getElementById('btnEditor').onclick = () =>
    ext.tabs.create({ url: ext.runtime.getURL('editor.html') });

  document.getElementById('btnSave').onclick = saveOptions;

  document.getElementById('cbEnable').onchange = function() { updateBadge(this.checked); };

  const _isMobile = /Android|iPhone|iPad|iPod|Mobile/i.test(navigator.userAgent);
  const btnOpenTab = document.getElementById('btnOpenTab');
  if (!_isMobile) {
    btnOpenTab?.remove();
  } else {
    btnOpenTab?.addEventListener('click', () => {
      ext.tabs.create({ url: ext.runtime.getURL('popup.html') });
    });
  }
});
