const ext = globalThis.browser ?? globalThis.chrome;
const HEARTBEAT_MS = 20_000;

function heartbeat() {
  try {
    const pending = ext.runtime.sendMessage({ action: 'offscreenHeartbeat' });
    if (pending && typeof pending.catch === 'function') pending.catch(() => {});
  } catch (_) {
    // Worker sẽ được đánh thức lại ở nhịp kế tiếp.
  }
}

heartbeat();
setInterval(heartbeat, HEARTBEAT_MS);
