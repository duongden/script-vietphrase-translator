/**
 * inject.js — Content Script v4
 */

const ext = globalThis.browser ?? globalThis.chrome;

function runtimeSendMessage(message, callback) {
  try {
    if (callback) {
      const result = ext.runtime.sendMessage(message);
      if (result && typeof result.then === 'function') {
        result.then(
          value => callback(value),
          () => callback(undefined)
        );
      } else {
        ext.runtime.sendMessage(message, callback);
      }
      return;
    }
    return ext.runtime.sendMessage(message);
  } catch (_error) {
    if (callback) callback(undefined);
    else return Promise.resolve(undefined);
  }
}

function storageGet(area, key) {
  return Promise.resolve(ext.storage[area].get(key));
}

function storageSet(area, value) {
  return Promise.resolve(ext.storage[area].set(value));
}

const SEP        = '\x00\uf0f3\x00';
const CHINESE_RE = /[\u3400-\u9FFF]/;

function fixVietnamese(text) {
  return (text ?? '').toString().normalize('NFC');
}

let settings = {
  enable: true,
  heightauto: true, widthauto: false, scaleauto: true,
  enableajax: false, enablescript: true,
  delayMutation: 200, delayTrans: 120,
};

let deferDelay    = 200;   // = settings.delayMutation
let translateDelay = 120;  // = settings.delayTrans
let mutLock    = false;
let deferCheck = false;
let firstTrans = true;
let observer   = null;
let _translateRunning = false; // mutex tránh chạy đồng thời
let _translateSession = 0;    // tăng khi cancel → làm lỗi thời các chunk đang chờ

// ═══════════════════════════════════════════════════════
// CSS injection
// ═══════════════════════════════════════════════════════
function injectThemeStyle() {
  if (document.getElementById('_vp_theme_style')) return;
  const s = document.createElement('style');
  s.id = '_vp_theme_style';
  s.textContent = `
    ._vp_ui {
      color-scheme: light dark;
      --vp-bg: rgba(255, 255, 255, 0.85);
      --vp-text: #1e293b;
      --vp-primary: #6366f1;
      --vp-primary-bg: #e0e7ff;
      --vp-border: rgba(0, 0, 0, 0.08);
      --vp-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
      --vp-glass: blur(16px) saturate(180%);
    }
    @media (prefers-color-scheme: dark) {
      ._vp_ui {
        --vp-bg: rgba(30, 41, 59, 0.82);
        --vp-text: #f1f5f9;
        --vp-primary: #818cf8;
        --vp-primary-bg: #1e1b4b;
        --vp-border: rgba(255, 255, 255, 0.1);
        --vp-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
      }
    }
    ._vp_ui, ._vp_ui * {
      box-sizing: border-box;
      font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Noto Sans", Arial, sans-serif;
      text-rendering: optimizeLegibility;
      -webkit-font-smoothing: antialiased;
    }
    ._vp_translated_parent {
      font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Noto Sans", Arial, sans-serif !important;
      text-rendering: optimizeLegibility;
      -webkit-font-smoothing: antialiased;
    }
    #_vp_float_panel {
      position: fixed; right: 16px; bottom: calc(96px + env(safe-area-inset-bottom, 0px));
      z-index: 2147483646;
      display: flex; flex-direction: column; align-items: flex-end; gap: 8px; pointer-events: none;
    }
    #_vp_float_panel > * { pointer-events: auto; }
    .vp-fpanel-btn {
      display: flex; align-items: center; justify-content: center; gap: 0;
      width: 44px; height: 44px; padding: 0;
      background: var(--vp-bg); color: var(--vp-text);
      border: 1px solid var(--vp-border); border-radius: 12px;
      box-shadow: var(--vp-shadow); backdrop-filter: var(--vp-glass);
      cursor: pointer; font-size: 12px; font-weight: 700;
      overflow: hidden; white-space: nowrap;
      transition: all 0.3s ease;
    }
    .vp-fpanel-btn .fp-label { display: none; }
    #_vp_float_panel.vp-expanded .vp-fpanel-btn {
      width: auto; padding: 10px 14px; gap: 8px; justify-content: flex-start;
    }
    #_vp_float_panel.vp-expanded .vp-fpanel-btn .fp-label { display: inline; }
    #_vp_float_panel.vp-collapsed .vp-fpanel-btn {
      width: 44px; height: 44px; padding: 0; gap: 0; justify-content: center;
    }
    #_vp_float_panel.vp-collapsed .vp-fpanel-btn:not(.vp-panel-toggle) {
      display: none;
    }
    #_vp_float_panel.vp-collapsed .vp-fpanel-btn .fp-label {
      display: none !important;
    }
    #_vp_float_panel.vp-expanded .vp-fpanel-btn .fp-icon { margin: 0; }
    .vp-fpanel-btn .fp-icon { width: 20px; height: 20px; flex-shrink: 0; display: flex; align-items: center; justify-content: center; margin: 0 auto; }
    .vp-fpanel-btn .fp-icon svg { width: 100%; height: 100%; fill: currentColor; }
    .vp-fpanel-btn.green { color: #10b981; }
    .vp-fpanel-btn.off { opacity: 0.6; }
    .vp-panel-toggle { border-style: dashed; }
    @media (hover: hover) {
      #_vp_float_panel.vp-expanded .vp-fpanel-btn:hover {
        width: auto; padding: 10px 14px; gap: 8px; justify-content: flex-start;
        transform: translateY(-2px); border-color: var(--vp-primary);
      }
      #_vp_float_panel.vp-expanded .vp-fpanel-btn:hover .fp-label { display: inline; }
    }

    #_vp_tooltip {
      position: fixed; z-index: 2147483647; pointer-events: none;
      background: var(--vp-bg); color: var(--vp-text);
      padding: 12px 18px; border-radius: 16px; border: 1px solid var(--vp-border);
      box-shadow: var(--vp-shadow); backdrop-filter: var(--vp-glass);
      font-size: 15px; line-height: 1.6; max-width: 400px; word-break: break-word;
      font-family: inherit;
    }

    @media (max-width: 768px) {
      #_vp_float_panel { right: 12px; bottom: calc(116px + env(safe-area-inset-bottom, 0px)); }
    }
  `;
  (document.head || document.documentElement).appendChild(s);
}

// ═══════════════════════════════════════════════════════
// Node classification — phân loại ưu tiên dịch
// ═══════════════════════════════════════════════════════
const VP_EXCLUDE_IDS = new Set([
  '_vp_tooltip','_vp_edit_dialog','_vp_edit_backdrop',
  '_vp_float_panel','_vp_theme_style'
]);

// Priority: 0=body text (cao nhất), 1=article/main/section, 2=aside/nav, 3=footer
function getNodePriority(el) {
  if (!el) return 3;
  const tag = el.tagName;
  if (!tag) return 3;
  if (tag === 'ARTICLE' || tag === 'MAIN' || tag === 'SECTION') return 1;
  if (tag === 'ASIDE'   || tag === 'NAV'  || tag === 'HEADER')  return 2;
  if (tag === 'FOOTER')                                          return 3;
  return 0;
}

function recurTraver(node, arr, texts) {
  if (!node) return;
  const tag = node.tagName;
  if (tag === 'SCRIPT' || tag === 'STYLE' || tag === 'NOSCRIPT') return;
  const id = node.id || '';
  if (VP_EXCLUDE_IDS.has(id)) return;

  for (const child of node.childNodes) {
    if (child.nodeType === 3) {
      if (child._vpSpaceNode) continue; // skip injected space nodes
      if (CHINESE_RE.test(child.textContent) && !child._vpTranslated) {
        arr.push(child); texts.push(child.textContent);
      }
    } else if (child.nodeType === 1) {
      recurTraver(child, arr, texts);
    }
  }
  if (node.shadowRoot) recurTraver(node.shadowRoot, arr, texts);
}

// ── Chunked translate cho DOM lớn ─────────────────────
// Chia batch lớn thành nhiều chunk nhỏ, dịch tuần tự
// tránh block main thread và timeout message
const CHUNK_SIZE = 80; // số text node mỗi lần gửi

// ── Regex kiểm tra ký tự Việt/Latin ──────────────────
const VIET_END_RE   = /[a-zA-Z\u00C0-\u1EF9]$/;   // kết thúc bằng chữ (không kể dấu chấm)
const VIET_START_RE = /^[a-zA-Z\u00C0-\u1EF9]/;    // bắt đầu bằng chữ

// Lấy ký tự CUỐI của text/element node (đệ quy vào lastChild)
function getTrailingChar(node) {
  if (!node) return '';
  if (node._vpSpaceNode) return ' ';
  if (node.nodeType === 3) {
    const t = node.textContent;
    return t ? t[t.length - 1] : '';
  }
  if (node.nodeType === 1) {
    if (VP_EXCLUDE_IDS.has(node.id || '')) return '';
    // Đệ quy vào lastChild
    for (let c = node.lastChild; c; c = c.previousSibling) {
      const ch = getTrailingChar(c);
      if (ch) return ch;
    }
  }
  return '';
}

// Lấy ký tự ĐẦU của text/element node (đệ quy vào firstChild)
function getLeadingChar(node) {
  if (!node) return '';
  if (node._vpSpaceNode) return ' ';
  if (node.nodeType === 3) {
    const t = node.textContent;
    return t ? t[0] : '';
  }
  if (node.nodeType === 1) {
    if (VP_EXCLUDE_IDS.has(node.id || '')) return '';
    for (let c = node.firstChild; c; c = c.nextSibling) {
      const ch = getLeadingChar(c);
      if (ch) return ch;
    }
  }
  return '';
}

function hasBoundaryChar(node) {
  return !!(getLeadingChar(node) || getTrailingChar(node));
}

function getPrevMeaningfulSibling(node) {
  if (!node) return null;
  let cur = node.previousSibling;
  while (cur) {
    if (hasBoundaryChar(cur)) return cur;
    cur = cur.previousSibling;
  }
  return null;
}

function getNextMeaningfulSibling(node) {
  if (!node) return null;
  let cur = node.nextSibling;
  while (cur) {
    if (hasBoundaryChar(cur)) return cur;
    cur = cur.nextSibling;
  }
  return null;
}

// Inject space node giữa prev và next nếu chưa có
function injectSpaceBetween(parent, before, after) {
  if (!parent || !before || !after) return;
  let cur = before.nextSibling;
  while (cur && cur !== after) {
    if (cur._vpSpaceNode) return;
    if (cur.nodeType === 3 && /\s/.test(cur.textContent || '')) return;
    if (hasBoundaryChar(cur)) return;
    cur = cur.nextSibling;
  }
  if (cur !== after) return;
  const sp = document.createTextNode(' ');
  sp._vpSpaceNode = true;
  parent.insertBefore(sp, after);
}

// Sau khi dịch xong toàn bộ batch, fix space ở RANH GIỚI
// giữa mỗi text node đã dịch và siblings của PARENT nó
function fixSpacingForNode(textNode) {
  if (textNode._vpSpaceNode) return;
  const parent = textNode.parentElement;
  if (!parent) return;

  // Trường hợp quan trọng nhất:
  // <p>textNode<a>link</a>textNode</p>
  // Cần fix khoảng cách ở 2 ranh giới:
  //   1. textNode → nextSibling (element <a>)
  //   2. element <a> → nextSibling (text node sau link)
  //
  // Với mỗi text node đã dịch, kiểm tra:
  //   A. Biên giới TRƯỚC textNode: previousSibling của textNode
  //   B. Biên giới SAU textNode: nextSibling của textNode
  //
  // Khi textNode nằm TRONG <a>:
  //   Kiểm tra thêm parent (<a>) với siblings của <a>

  // ── Kiểm tra biên giới trong DOM ──────────────────────────
  const checkAndFix = (nodeA, nodeB) => {
    if (!nodeA || !nodeB) return;
    const trailing = getTrailingChar(nodeA);
    const leading  = getLeadingChar(nodeB);
    if (!trailing || !leading) return;
    if (trailing === ' ' || leading === ' ') return; // đã có space
    if (VIET_END_RE.test(trailing) && VIET_START_RE.test(leading)) {
      injectSpaceBetween(nodeA.parentNode, nodeA, nodeB);
    }
  };

  // A. Biên giới với previousSibling
  checkAndFix(getPrevMeaningfulSibling(textNode), textNode);
  // B. Biên giới với nextSibling
  checkAndFix(textNode, getNextMeaningfulSibling(textNode));

  const INLINE_PARENTS = new Set(['A','SPAN','B','STRONG','I','EM','S','U','MARK','SMALL','LABEL']);
  for (let cur = parent; cur && cur !== document.body; cur = cur.parentElement) {
    if (!INLINE_PARENTS.has(cur.tagName)) break;
    checkAndFix(getPrevMeaningfulSibling(cur), cur);
    checkAndFix(cur, getNextMeaningfulSibling(cur));
  }
}

async function translateChunked(arr, texts, session) {
  // Pass 1: dịch tất cả chunks — CHỈ ghi textContent, chưa fix spacing
  for (let start = 0; start < arr.length; start += CHUNK_SIZE) {
    if (_translateSession !== session) return; // bị hủy — thoát ngay

    const chunkArr   = arr.slice(start, start + CHUNK_SIZE);
    const chunkTexts = texts.slice(start, start + CHUNK_SIZE);

    await new Promise(resolve => {
      runtimeSendMessage(
        { action: 'translateWithMap', text: chunkTexts.join(SEP) },
        res => {
          if (_translateSession !== session) { resolve(); return; } // response lỗi thời
          if (ext.runtime.lastError || !res?.translated) { resolve(); return; }
          const translated = res.translated.split(SEP);
          const tokenMaps  = res.tokenMaps || [];
          chunkArr.forEach((node, i) => {
            if (translated[i] === undefined) return;
            node._vpOrigin     = node.textContent;
            node.textContent   = fixVietnamese(translated[i]);
            node._vpTranslated = true;
            node._vpTokenMap   = tokenMaps[i] || null;

            const parent = node.parentElement;
            if (parent) {
              parent.classList.add('_vp_translated_parent');
            }
          });
          resolve();
        }
      );
    });

    // Yield giữa các chunk để browser không bị freeze
    if (start + CHUNK_SIZE < arr.length) {
      await new Promise(r => setTimeout(r, 0));
      if (_translateSession !== session) return; // kiểm tra lại sau yield
    }
  }

  // Pass 2 GLOBAL: fix spacing SAU KHI tất cả chunks đã dịch xong
  if (_translateSession !== session) return;
  for (const node of arr) {
    if (node._vpTranslated) fixSpacingForNode(node);
  }
}

async function realtimeTranslate(force = false, rootNodes = null) {
  if (!settings.enable && !force) return;
  if (_translateRunning && !rootNodes) return; // mutex tránh chạy đồng thời cho full scan
  
  if (!rootNodes) _translateRunning = true;
  const _session = ++_translateSession;

  // Thu thập nodes theo priority: ưu tiên nội dung chính trước
  const priorityBuckets = [[], [], [], []]; // 4 mức ưu tiên

  // Duyệt các node cần dịch
  function collectByPriority(node) {
    if (!node) return;
    const tag = node.nodeType === 1 ? node.tagName : '';
    if (tag === 'SCRIPT' || tag === 'STYLE' || tag === 'NOSCRIPT') return;
    const id = node.nodeType === 1 ? (node.id || '') : '';
    if (VP_EXCLUDE_IDS.has(id)) return;

    if (node.nodeType === 3) {
      if (CHINESE_RE.test(node.textContent) && !node._vpTranslated) {
        const prio = getNodePriority(node.parentElement);
        const arr = [node], texts = [node.textContent];
        priorityBuckets[prio].push({ arr, texts });
      }
    } else if (node.nodeType === 1 || node.nodeType === 11) { // 11 = ShadowRoot
      const prio = getNodePriority(node);
      const arr = []; const texts = [];
      recurTraver(node, arr, texts);
      if (arr.length) priorityBuckets[prio].push({ arr, texts });
    }
  }

  if (rootNodes) {
    rootNodes.forEach(n => collectByPriority(n));
  } else if (document.body) {
    for (const child of document.body.children) {
      collectByPriority(child);
    }
    // Title
    const titleEl = document.querySelector('title');
    if (titleEl) {
      const arr = []; const texts = [];
      recurTraver(titleEl, arr, texts);
      if (arr.length) priorityBuckets[0].unshift({ arr, texts });
    }
  }

  // Tổng hợp theo thứ tự priority
  const allArr = [], allTexts = [];
  const seenNodes = new Set();
  for (const bucket of priorityBuckets) {
    for (const { arr, texts } of bucket) {
      for (let i = 0; i < arr.length; i++) {
        if (seenNodes.has(arr[i])) continue;
        seenNodes.add(arr[i]);
        allArr.push(arr[i]);
        allTexts.push(texts[i]);
      }
    }
  }

  if (!allArr.length) { if (!rootNodes) _translateRunning = false; return; }

  // Dịch theo chunk (tối ưu large DOM)
  try {
    await translateChunked(allArr, allTexts, _session);

    if (_translateSession === _session) {
      if (firstTrans) {
        firstTrans = false;
        if (settings.enablescript !== false) startObserver();
        if (settings.enableajax) attachAjaxInterceptor();
        initGlobalEvents(); // Thêm event delegation
      }
      setTimeout(() => removeOverflow(allArr), 80);
    }
  } finally {
    if (!rootNodes) _translateRunning = false;
  }
}

function cancelTranslation() {
  _translateSession++;     // làm lỗi thời tất cả chunks/callbacks đang chờ
  _translateRunning = false; // cho phép translate mới bắt đầu ngay
}

function restoreAndRetranslate() {
  cancelTranslation(); // ưu tiên hủy translation đang chạy trước
  if (observer) observer.disconnect();
  function restore(node) {
    if (!node) return;
    if (node.tagName === 'SCRIPT' || node.tagName === 'STYLE') return;
    const toRemove = [];
    for (const child of node.childNodes) {
      // Dọn space nodes đã inject
      if (child._vpSpaceNode) { toRemove.push(child); continue; }
      if (child.nodeType === 3 && child._vpOrigin) {
        child.textContent   = child._vpOrigin;
        child._vpOrigin     = undefined;
        child._vpTranslated = false;
        if (child.parentElement)
          child.parentElement.classList.remove('_vp_translated_parent');
      } else if (child.nodeType === 1) {
        restore(child);
      }
    }
    for (const n of toRemove) n.remove();
    if (node.shadowRoot) restore(node.shadowRoot);
  }
  restore(document.body);
  firstTrans = true;
  setTimeout(() => realtimeTranslate(true), 100);
}

function reloadDictsAndRetranslate(done) {
  runtimeSendMessage({ action: 'reloadDicts' }, () => {
    restoreAndRetranslate();
    if (typeof done === 'function') done();
  });
}

// ═══════════════════════════════════════════════════════
// MutationObserver
// ═══════════════════════════════════════════════════════
function startObserver() {
  if (observer) observer.disconnect();
  const pendingNodes = new Set();
  
  observer = new MutationObserver((mutations) => {
    if (settings.enable === false) return;
    
    // Thu thập các node mới được thêm vào
    for (const m of mutations) {
      if (m.type === 'childList') {
        for (const n of m.addedNodes) {
          if (n.nodeType === 3 || n.nodeType === 1) pendingNodes.add(n);
        }
      }
    }

    if (mutLock) { deferCheck = true; return; }
    mutLock = true;
    
    setTimeout(() => {
      mutLock = false;
      if (deferCheck || pendingNodes.size > 0) {
        deferCheck = false;
        const nodes = [...pendingNodes];
        pendingNodes.clear();
        realtimeTranslate(false, nodes);
      }
    }, deferDelay);
  });
  observer.observe(document.body, { childList: true, subtree: true });
}

// ═══════════════════════════════════════════════════════
// Tooltip - Event Delegation
// ═══════════════════════════════════════════════════════
function initGlobalEvents() {
  if (_isTouchDevice) return;
  document.body.addEventListener('mouseover', e => {
    const p = e.target.closest('._vp_translated_parent');
    if (p) onNodeMouseEnter({ currentTarget: p, clientX: e.clientX, clientY: e.clientY });
  });
  document.body.addEventListener('mouseout', e => {
    const p = e.target.closest('._vp_translated_parent');
    if (p) onNodeMouseLeave();
  });
  document.body.addEventListener('mousemove', e => {
    const p = e.target.closest('._vp_translated_parent');
    if (p) onNodeMouseMove(e);
  });
}

// ═══════════════════════════════════════════════════════
// Tooltip
// ═══════════════════════════════════════════════════════
const _isTouchDevice = navigator.maxTouchPoints > 0 || 'ontouchstart' in window;
let _tooltip = null;
let _tipTimer = null;

function getTooltip() {
  if (_tooltip) return _tooltip;
  injectThemeStyle();
  _tooltip = document.createElement('div');
  _tooltip.id = '_vp_tooltip';
  _tooltip.className = '_vp_ui';
  _tooltip.style.display = 'none';
  document.body.appendChild(_tooltip);
  return _tooltip;
}

function onNodeMouseEnter(e) {
  let original = '';
  for (const child of e.currentTarget.childNodes)
    if (child.nodeType === 3 && child._vpOrigin) original += child._vpOrigin;
  if (!original) return;
  clearTimeout(_tipTimer);
  const tip = getTooltip();
  tip.textContent = original;
  tip.style.display = 'block';
  positionTip(e);
}
function onNodeMouseMove(e) { if (_tooltip?.style.display !== 'none') positionTip(e); }
function onNodeMouseLeave() {
  clearTimeout(_tipTimer);
  _tipTimer = setTimeout(() => { if (_tooltip) _tooltip.style.display = 'none'; }, 120);
}
function positionTip(e) {
  if (!_tooltip) return;
  const vw = window.innerWidth, vh = window.innerHeight;
  let x = e.clientX + 14, y = e.clientY + 16;
  const tw = Math.min(360, vw * 0.45);
  if (x + tw > vw - 12) x = e.clientX - tw - 12;
  if (y + 80  > vh)      y = e.clientY - 70;
  _tooltip.style.left = x + 'px';
  _tooltip.style.top  = y + 'px';
}

// ═══════════════════════════════════════════════════════
// Selection — lấy chữ Hán gốc từ selection hoặc right-click
// ═══════════════════════════════════════════════════════
let _lastRightClickEl  = null;
let _lastSelectionData = null;
let _lastSelectionRange = null;
let _lastSelectionText = '';

function isTokenPunctOrSpace(ch) {
  return !ch || /[\s,，。；;：:、.!?'"“”‘’()\[\]{}«»—\-]/.test(ch);
}

function clampOffset(n, max) {
  return Math.max(0, Math.min(Number.isFinite(n) ? n : 0, max));
}

function getTokenRanges(node) {
  if (!node || node.nodeType !== 3) return [];
  const nodeText = String(node.textContent || '');
  const tokenMap = Array.isArray(node._vpTokenMap) ? node._vpTokenMap : [];
  const ranges = [];

  for (const tok of tokenMap) {
    const start = Number(tok?.start);
    const end   = Number(tok?.end);
    const han   = String(tok?.han || '');
    const viet  = String(tok?.viet || '');
    if (!han || !viet) continue;
    if (!Number.isFinite(start) || !Number.isFinite(end) || end <= start) continue;
    if (start < 0 || end > nodeText.length) continue;
    ranges.push({ han, viet, start, end });
  }

  return ranges;
}

function trimSelectionOffsets(nodeText, startOff, endOff) {
  const len = nodeText.length;
  let start = clampOffset(startOff, len);
  let end   = clampOffset(endOff, len);
  if (end < start) [start, end] = [end, start];

  while (start < end && isTokenPunctOrSpace(nodeText[start])) start++;
  while (end > start && isTokenPunctOrSpace(nodeText[end - 1])) end--;
  return { start, end };
}

function pickTokenRangesBySelection(ranges, startOff, endOff) {
  if (!ranges.length) return [];
  const start = Math.min(startOff, endOff);
  const end   = Math.max(startOff, endOff);
  let picked = ranges.filter(r => r.end > start && r.start < end);
  if (picked.length) return picked;

  const mid = start === end ? start : (start + end) / 2;
  let best = null;
  let bestDist = Infinity;
  for (const r of ranges) {
    let dist = 0;
    if (mid < r.start) dist = r.start - mid;
    else if (mid > r.end) dist = mid - r.end;
    if (dist < bestDist) {
      bestDist = dist;
      best = r;
    }
  }
  return best ? [best] : [];
}

// Lấy token (Han + Viet) tại vị trí chuột, dùng _vpTokenMap hoặc getTokenAtPosition
function getWordAtPoint(x, y) {
  // Lấy text node và offset tại vị trí chuột
  let node, offset;
  if (document.caretRangeFromPoint) {
    const range = document.caretRangeFromPoint(x, y);
    if (!range) return null;
    node   = range.startContainer;
    offset = range.startOffset;
  } else if (document.caretPositionFromPoint) {
    const cpos = document.caretPositionFromPoint(x, y);
    if (!cpos) return null;
    node   = cpos.offsetNode;
    offset = cpos.offset;
  }
  if (!node) return null;

  // Element node → thử lấy text node con
  if (node.nodeType === 1) {
    const idx = Math.min(offset, node.childNodes.length - 1);
    for (let d = 0; d <= 2; d++) {
      for (const i of [idx - d, idx + d]) {
        const ch = node.childNodes[i];
        if (ch && ch.nodeType === 3 && ch._vpOrigin) { node = ch; offset = 0; break; }
      }
      if (node.nodeType === 3 && node._vpOrigin) break;
    }
    if (node.nodeType !== 3 || !node._vpOrigin) return null;
  }

  // Space node hoặc node không có _vpOrigin → thử sibling
  if (node.nodeType === 3 && !node._vpOrigin) {
    const prev = node.previousSibling;
    const next = node.nextSibling;
    if (prev && prev.nodeType === 3 && prev._vpOrigin) {
      node = prev; offset = prev.textContent.length;
    } else if (next && next.nodeType === 3 && next._vpOrigin) {
      node = next; offset = 0;
    } else { return null; }
  }

  if (node.nodeType !== 3 || !node._vpOrigin) return null;

  const nodeText  = node.textContent;
  const origin    = node._vpOrigin;
  const ranges    = getTokenRanges(node);
  const pos       = Math.max(0, Math.min(offset, nodeText.length - 1));

  // ── Dùng tokenMap.start/end để tra trực tiếp tại caret ──
  if (ranges.length) {
    let best = ranges.find(r => pos >= r.start && pos < r.end);
    if (!best) {
      let bestDist = Infinity;
      for (const r of ranges) {
        const dist = pos < r.start ? r.start - pos : pos > r.end ? pos - r.end : 0;
        if (dist < bestDist) {
          bestDist = dist;
          best = r;
        }
      }
    }
    if (best) return { han: best.han, viet: best.viet, _resolved: true };
  }

  // ── Fallback: dùng getTokenAtPosition (position-based, chính xác hơn reverseTranslate) ──
  runtimeSendMessage(
    { action: 'getTokenAtPosition', han: origin, offset: pos },
    res => { if (res?.han) _lastSelectionData = { han: res.han, viet: res.viet, _resolved: true }; }
  );

  // Trích syllable tại cursor để hiển thị tạm
  const sylls2 = nodeText.split(' ');
  let cp = 0, si = 0;
  for (let i = 0; i < sylls2.length; i++) {
    si = i;
    if (pos <= cp + sylls2[i].length) break;
    cp += sylls2[i].length + 1;
  }
  const word = (sylls2[si] || '').replace(/[.,!?;:'"]+/g, '').trim();
  return { han: '', viet: word || '', _pending: true };
}

document.addEventListener('contextmenu', e => {
  _lastRightClickEl  = e.target;
  const sel = window.getSelection();
  if (!sel || sel.isCollapsed || sel.rangeCount === 0) {
    // Không có selection → thử lấy từ tại vị trí chuột
    const wp = getWordAtPoint(e.clientX, e.clientY);
    if (wp) {
      _lastSelectionData = wp;
    } else {
      // getWordAtPoint thất bại → dùng getHanFromEl nhưng đánh dấu _pending
      // để openWithData biết cần chờ getTokenAtPosition
      const fromEl = getHanFromEl(e.target);
      if (fromEl) {
        const cjk = (fromEl.han.match(/[\u4e00-\u9fff\u3400-\u4dbf]/g) || []).length;
        if (cjk > 8) {
          // Han quá dài → fire getTokenAtPosition với caret offset trong toàn bộ viet text
          let cOffset = 0;
          try {
            const r = document.caretRangeFromPoint(e.clientX, e.clientY);
            if (r) {
              const parent = e.target.nodeType === 1 ? e.target : e.target.parentElement;
              if (parent) {
                const mr = document.createRange();
                mr.setStart(parent, 0);
                mr.setEnd(r.startContainer, r.startOffset);
                cOffset = mr.toString().length;
              }
            }
          } catch (_) {}
          _lastSelectionData = { han: '', viet: '', _pending: true };
          runtimeSendMessage(
            { action: 'getTokenAtPosition', han: fromEl.han, offset: cOffset },
            res => { if (res?.han) _lastSelectionData = { han: res.han, viet: res.viet, _resolved: true }; }
          );
        } else {
          _lastSelectionData = fromEl;
        }
      } else {
        _lastSelectionData = null;
      }
    }
  } else {
    _lastSelectionData = extractSelectionData();
  }
});

function getHanFromEl(el) {
  if (!el) return null;

  function scanTranslatedSubtree(node) {
    let han = '', viet = '';
    const root = node.nodeType === 3 ? node.parentElement : node;
    if (!root) return null;

    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, null);
    let cur;
    while ((cur = walker.nextNode())) {
      const text = cur.textContent || '';
      if (!text) continue;
      if (cur._vpOrigin) {
        han  += cur._vpOrigin;
        viet += text;
      } else if (cur._vpSpaceNode) {
        viet += text;
      }
    }
    return han ? { han: han.trim(), viet: viet.trim() } : null;
  }

  for (let cur = el; cur && cur !== document.body; cur = cur.parentElement) {
    if (cur.nodeType === 3 && cur._vpOrigin) {
      return { han: cur._vpOrigin.trim(), viet: cur.textContent.trim() };
    }
    const r = scanTranslatedSubtree(cur);
    if (r) return r;
  }
  return null;
}

function requestReverseSelectionFromContext(context, selectedViet, selText) {
  if (!context?.han || !selectedViet) return false;
  runtimeSendMessage(
    { action: 'reverseTranslate', originalHan: context.han, selectedViet },
    res => {
      if (res?.result?.han) {
        _lastSelectionData = { ...res.result, selText, _resolved: true };
      } else if (context?.han) {
        _lastSelectionData = { han: context.han, viet: context.viet || selectedViet, selText, _resolved: true };
      }
    }
  );
  return true;
}

function mapSelectedVietToHan(node, startOff, endOff) {
  if (!node || node.nodeType !== 3 || !node._vpOrigin) return null;
  const nodeText = node.textContent || '';
  const ranges = getTokenRanges(node);
  if (!ranges.length) return null;

  const trimmed = trimSelectionOffsets(nodeText, startOff, endOff);
  const pick = pickTokenRangesBySelection(ranges, trimmed.start, trimmed.end);
  if (!pick.length) return null;

  let han = pick.map(r => r.han).join('').trim();
  const first = pick[0];
  const last  = pick[pick.length - 1];
  let viet = nodeText.slice(first.start, last.end).trim();
  if (!han) return null;

  han = han.replace(/^[\s,，。；;：:、]+|[\s,，。；;：:、]+$/g, '');
  viet = viet.replace(/^[\s,，。；;：:、]+|[\s,，。；;：:、]+$/g, '');
  if (!han) return null;
  return { han, viet };
}

function extractSelectionFromOriginNode(node, startOff, endOff) {
  if (!node || node.nodeType !== 3 || !node._vpOrigin) return null;
  const nodeText = node.textContent || '';
  const origin   = node._vpOrigin || '';
  const selectedViet = nodeText.slice(startOff, endOff);
  if (!selectedViet.trim()) return null;

  const mapped = mapSelectedVietToHan(node, startOff, endOff);
  if (mapped?.han) return mapped;

  if ((startOff === 0 && endOff >= nodeText.length) ||
      (endOff - startOff) / Math.max(1, nodeText.length) >= 0.85) {
    return { han: origin.trim(), viet: nodeText.trim() };
  }

  return { han: '', viet: selectedViet };
}

function rangeIntersectsTextNode(range, node) {
  if (!range || !node || node.nodeType !== 3) return false;
  try {
    if (typeof range.intersectsNode === 'function') return range.intersectsNode(node);
    const nr = document.createRange();
    nr.selectNodeContents(node);
    return !(range.compareBoundaryPoints(Range.START_TO_END, nr) > 0 ||
             range.compareBoundaryPoints(Range.END_TO_START, nr) < 0);
  } catch (_) {
    return false;
  }
}

function getSelectionOffsetsForTextNode(range, node) {
  if (!range || !node || node.nodeType !== 3) return null;
  if (!rangeIntersectsTextNode(range, node)) return null;

  const textLen = node.textContent.length;
  let startOff = 0;
  let endOff = textLen;

  try {
    const nr = document.createRange();
    nr.selectNodeContents(node);

    const startsInside = range.compareBoundaryPoints(Range.START_TO_START, nr) >= 0 &&
                         range.compareBoundaryPoints(Range.START_TO_END, nr) <= 0;
    const endsInside   = range.compareBoundaryPoints(Range.END_TO_START, nr) >= 0 &&
                         range.compareBoundaryPoints(Range.END_TO_END, nr) <= 0;

    if (startsInside) {
      if (range.startContainer === node) {
        startOff = range.startOffset;
      } else {
        const pre = document.createRange();
        pre.selectNodeContents(node);
        pre.setEnd(range.startContainer, range.startOffset);
        startOff = pre.toString().length;
      }
    }

    if (endsInside) {
      if (range.endContainer === node) {
        endOff = range.endOffset;
      } else {
        const pre = document.createRange();
        pre.selectNodeContents(node);
        pre.setEnd(range.endContainer, range.endOffset);
        endOff = pre.toString().length;
      }
    }
  } catch (_) {
    return null;
  }

  startOff = clampOffset(startOff, textLen);
  endOff   = clampOffset(endOff, textLen);
  if (endOff < startOff) [startOff, endOff] = [endOff, startOff];
  return { startOff, endOff };
}

function extractSelectionData(rangeArg = null, selTextArg = '') {
  const sel = window.getSelection();
  const range = rangeArg || (sel && !sel.isCollapsed && sel.rangeCount > 0 ? sel.getRangeAt(0) : null);
  const selText = String(selTextArg || (sel && !sel.isCollapsed ? sel.toString() : '')).trim();

  if (!range) {
    return _lastSelectionData || getHanFromEl(_lastRightClickEl);
  }
  if (!selText) return _lastSelectionData || getHanFromEl(_lastRightClickEl);

  // Thu thập node + offset từ selection
  const sc = range.startContainer;
  const ec = range.endContainer;

  // ── Tìm text node đơn nhất được select ─────────────────
  // Trường hợp thường gặp: user select vài từ trong 1 text node dài
  if (sc === ec && sc.nodeType === 3 && sc._vpOrigin) {
    const node         = sc;
    const nodeText     = node.textContent;
    const origin       = node._vpOrigin;
    const startOff     = range.startOffset;
    const endOff       = range.endOffset;
    const selectedViet = nodeText.slice(startOff, endOff).trim();

    if (!selectedViet) return null;

    const extracted = extractSelectionFromOriginNode(node, startOff, endOff);
    if (extracted?.han) {
      return { ...extracted, selText, _resolved: true };
    }

    // Nếu chọn toàn bộ hoặc gần hết node → lấy toàn bộ luôn
    if ((startOff === 0 && endOff >= nodeText.length) ||
        (endOff - startOff) / Math.max(1, nodeText.length) >= 0.85) {
      return { han: origin.trim(), viet: nodeText.trim(), selText, _resolved: true };
    }

    runtimeSendMessage(
      { action: 'reverseTranslate', originalHan: origin, selectedViet },
      res => {
        if (res?.result?.han) {
          _lastSelectionData = { ...res.result, selText, _resolved: true };
        } else {
          // reverseTranslate thất bại → fallback lấy toàn bộ origin
          _lastSelectionData = { han: origin.trim(), viet: nodeText.trim(), selText, _resolved: true };
        }
      }
    );

    return { han: '', viet: selectedViet, selText, _pending: true };
  }

  // ── Multi-node hoặc element container ──────────────────
  const hanParts = [];
  const vietParts = [];

  const collectFromNode = (node, startOff, endOff) => {
    if (!node || node.nodeType !== 3) return;
    const nodeText = node.textContent || '';
    const start = clampOffset(startOff, nodeText.length);
    const end   = clampOffset(endOff, nodeText.length);
    if (end <= start) return;

    if (node._vpSpaceNode) {
      vietParts.push(nodeText.slice(start, end));
      return;
    }

    if (node._vpOrigin) {
      const extracted = extractSelectionFromOriginNode(node, start, end);
      if (extracted?.han) hanParts.push(extracted.han);
      if (extracted?.viet) vietParts.push(extracted.viet);
    } else if (CHINESE_RE.test(node.textContent)) {
      hanParts.push(nodeText.slice(start, end));
      vietParts.push(nodeText.slice(start, end));
    } else {
      vietParts.push(nodeText.slice(start, end));
    }
  };

  if (sc === ec) {
    if (sc.nodeType === 3) {
      collectFromNode(sc, range.startOffset, range.endOffset);
    } else if (sc.nodeType === 1) {
      const children = sc.childNodes;
      const end = Math.min(range.endOffset, children.length);
      for (let i = range.startOffset; i < end; i++) {
        const ch = children[i];
        if (ch.nodeType === 3) collectFromNode(ch, 0, ch.textContent.length);
        else if (ch.nodeType === 1) {
          for (const c of ch.childNodes)
            if (c.nodeType === 3) collectFromNode(c, 0, c.textContent.length);
        }
      }
    }
  } else {
    const VP_EXCL = new Set([
      '_vp_tooltip','_vp_edit_dialog','_vp_edit_backdrop',
      '_vp_float_panel','_vp_theme_style'
    ]);
    const isExcluded = n => {
      let el = n.nodeType === 1 ? n : n.parentElement;
      while (el && el !== document.body) {
        if (VP_EXCL.has(el.id || '')) return true;
        el = el.parentElement;
      }
      return false;
    };

    const ancestor = range.commonAncestorContainer;
    const root = ancestor.nodeType === 1 ? ancestor : ancestor.parentElement;
    if (!root) return getHanFromEl(_lastRightClickEl);

    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
      acceptNode: n => isExcluded(n) ? NodeFilter.FILTER_REJECT : NodeFilter.FILTER_ACCEPT
    });

    let node;
    while ((node = walker.nextNode())) {
      const offsets = getSelectionOffsetsForTextNode(range, node);
      if (!offsets) continue;
      if (offsets.startOff === offsets.endOff) continue;
      collectFromNode(node, offsets.startOff, offsets.endOff);
    }
  }

  let han = hanParts.join('');
  let viet = vietParts.join('');

  han = han.replace(/^[\s,，。；;：:、.!?'"“”‘’()\[\]{}«»—\-]+|[\s,，。；;：:、.!?'"“”‘’()\[\]{}«»—\-]+$/g, '');
  viet = viet.replace(/^\s+|\s+$/g, '');

  if (han) return { han, viet: viet || selText, selText };
  if (selText && CHINESE_RE.test(selText)) return { han: selText, viet: '', selText };
  const contextNode = sc?.nodeType === 1 ? sc : sc?.parentElement || _lastRightClickEl;
  const context = getHanFromEl(contextNode) || getHanFromEl(_lastRightClickEl);
  if (!han && selText && context?.han) {
    requestReverseSelectionFromContext(context, selText, selText);
    return { han: '', viet: viet || selText, selText, _pending: true };
  }
  const fromEl = context;
  if (fromEl) return fromEl;
  // selText is Latin (translated text) — keep as viet only, han must be Chinese
  if (selText) return { han: '', viet: selText, selText };
  return null;
}

function snapshotCurrentSelection() {
  const sel = window.getSelection();
  if (!sel || sel.isCollapsed || sel.rangeCount === 0) return;
  try {
    _lastSelectionRange = sel.getRangeAt(0).cloneRange();
  } catch (_) {
    _lastSelectionRange = null;
  }
  _lastSelectionText = sel.toString().trim();
  const data = extractSelectionData(_lastSelectionRange, _lastSelectionText);
  if (data) _lastSelectionData = data;
}

document.addEventListener('mouseup', () => {
  setTimeout(snapshotCurrentSelection, 0);
}, true);

document.addEventListener('selectionchange', () => {
  setTimeout(snapshotCurrentSelection, 0);
}, true);

document.addEventListener('keyup', e => {
  if (e.key === 'Shift' || e.key.startsWith('Arrow')) {
    setTimeout(snapshotCurrentSelection, 0);
  }
}, true);

function copyOriginal() {
  const data = _lastSelectionData;
  const text = data?.han || window.getSelection()?.toString() || '';
  if (!text) return;
  navigator.clipboard.writeText(text).catch(() => {
    const ta = Object.assign(document.createElement('textarea'),
      { value: text, style: 'position:fixed;opacity:0;top:0;left:0' });
    document.body.appendChild(ta); ta.focus(); ta.select();
    document.execCommand('copy'); ta.remove();
  });
}

// ═══════════════════════════════════════════════════════
// Edit dialog
// ═══════════════════════════════════════════════════════
function esc(s) {
  return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

function openEditDialog(type, hanText, currentViet) {
  document.getElementById('_vp_edit_dialog')?.remove();
  document.getElementById('_vp_edit_backdrop')?.remove();
  injectThemeStyle();

  const dial = document.createElement('div');
  dial.id = '_vp_edit_dialog'; dial.className = '_vp_ui';
  Object.assign(dial.style, {
    position:'fixed', zIndex:'2147483647', top:'50%', left:'50%',
    transform:'translate(-50%,-50%)',
    background:'var(--vp-bg)', color:'var(--vp-text)',
    border:'1px solid var(--vp-border)', borderRadius:'14px',
    padding:'24px', width:'400px', maxWidth:'94vw',
    boxShadow:'0 16px 48px var(--vp-shadow-lg)'
  });

  const isNames = type === 'Names';

  // ── Các hàm chuyển kiểu viết hoa tiếng Việt ──────────────
  // Tách đúng các từ có dấu (Unicode grapheme-aware bằng split(' '))
  const caseTransforms = {
    // aa → tất cả viết thường: "tiệt giáo"
    lower: s => s.toLowerCase(),

    // Aa → Chữ đầu từ đầu tiên viết hoa: "Tiệt giáo"
    titleFirst: s => {
      const words = s.toLowerCase().split(' ');
      if (words.length === 0) return s;
      words[0] = capWord(words[0]);
      return words.join(' ');
    },

    // aA → Chữ đầu từ thứ hai viết hoa: "tiệt Giáo"
    titleSecond: s => {
      const words = s.toLowerCase().split(' ');
      if (words.length >= 2) words[1] = capWord(words[1]);
      return words.join(' ');
    },

    // AA → Chữ đầu mỗi từ viết hoa: "Tiệt Giáo"
    titleAll: s => s.toLowerCase().split(' ').map(capWord).join(' '),
  };

  // Viết hoa ký tự đầu của một từ (hỗ trợ Unicode / dấu tiếng Việt)
  function capWord(w) {
    if (!w) return w;
    return [...w][0].toUpperCase() + [...w].slice(1).join('');
  }

  const btnBase = 'padding:5px 10px;border:1.5px solid var(--vp-border);border-radius:6px;' +
                  'cursor:pointer;font-size:12px;font-weight:700;background:var(--vp-bg2);' +
                  'color:var(--vp-text2);transition:background .12s,color .12s;';

  dial.innerHTML = `
    <div style="font-weight:700;font-size:17px;margin-bottom:16px;color:var(--vp-blue)">
      ${isNames ? 'Sửa tên riêng (Names)' : 'Sửa Vietphrase'}
    </div>

    <div style="margin-bottom:6px;font-size:12px;color:var(--vp-muted);font-weight:700;text-transform:uppercase;letter-spacing:.5px">Chữ Hán</div>
    <input id="_vp_d_han" type="text" value="${esc(hanText)}"
      style="margin-bottom:8px;font-family:'Noto Serif SC',serif;font-size:16px;border-color:var(--vp-blue-bd)">

    <div style="margin-bottom:14px;font-size:12px;color:var(--vp-muted)">
      Phiên âm: <span id="_vp_d_pa" style="font-style:italic;color:var(--vp-text2);font-family:inherit;letter-spacing:normal;word-spacing:normal;white-space:normal;text-transform:none">đang tra...</span>
    </div>

    <div style="margin-bottom:6px;font-size:12px;color:var(--vp-muted);font-weight:700;text-transform:uppercase;letter-spacing:.5px">
      ${isNames ? 'Tên Hán-Việt' : 'Nghĩa tiếng Việt'}
    </div>
    <input id="_vp_d_viet" type="text" value="${esc(currentViet || '')}"
      style="margin-bottom:10px;border-color:var(--vp-green-bd)">

    <!-- ── Nút chuyển kiểu viết hoa ── -->
    <div style="margin-bottom:16px">
      <div style="font-size:11px;color:var(--vp-muted);margin-bottom:6px;font-weight:600">
        Kiểu viết hoa:
      </div>
      <div style="display:flex;gap:6px;flex-wrap:wrap">
        <button id="_vp_c_lower"  style="${btnBase}" title="Viết thường: tiệt giáo">
          <span style="font-family:monospace;letter-spacing:-.5px">aa</span>
          <span style="font-size:10px;font-weight:400;opacity:.7;margin-left:3px">thường</span>
        </button>
        <button id="_vp_c_first"  style="${btnBase}" title="Hoa chữ đầu: Tiệt giáo">
          <span style="font-family:monospace;letter-spacing:-.5px">Aa</span>
          <span style="font-size:10px;font-weight:400;opacity:.7;margin-left:3px">đầu tiên</span>
        </button>
        <button id="_vp_c_second" style="${btnBase}" title="Hoa từ thứ hai: tiệt Giáo">
          <span style="font-family:monospace;letter-spacing:-.5px">aA</span>
          <span style="font-size:10px;font-weight:400;opacity:.7;margin-left:3px">thứ hai</span>
        </button>
        <button id="_vp_c_all"    style="${btnBase}" title="Hoa đầu mỗi từ: Tiệt Giáo">
          <span style="font-family:monospace;letter-spacing:-.5px">AA</span>
          <span style="font-size:10px;font-weight:400;opacity:.7;margin-left:3px">tất cả</span>
        </button>
      </div>
    </div>

    <div style="display:flex;gap:8px;justify-content:flex-end">
      <button id="_vp_d_del"
        style="padding:9px 14px;background:var(--vp-red-lt);color:var(--vp-red);border:1.5px solid var(--vp-red-bd);border-radius:7px;font-size:13px">
        Xóa khỏi dict
      </button>
      <button id="_vp_d_cancel"
        style="padding:9px 14px;background:var(--vp-bg2);color:var(--vp-text2);border:1.5px solid var(--vp-border);border-radius:7px;font-size:13px">
        Hủy
      </button>
      <button id="_vp_d_save"
        style="padding:9px 18px;background:var(--vp-blue-btn);color:#fff;border:none;border-radius:7px;font-size:13px;font-weight:700">
        Lưu
      </button>
    </div>
    <div id="_vp_d_msg" style="margin-top:12px;min-height:18px;font-size:12px;text-align:center;color:var(--vp-muted)"></div>
  `;
  document.body.appendChild(dial);
  dial.style.letterSpacing = 'normal';
  dial.style.wordSpacing = 'normal';
  dial.style.textTransform = 'none';
  dial.style.whiteSpace = 'normal';

  const CJK_RE = /[\u4e00-\u9fff\u3400-\u4dbf]/;

  // Fetch PA (phiên âm) từ background.js
  if (hanText && CJK_RE.test(hanText)) {
    runtimeSendMessage({ action: 'getPA', han: hanText }, res => {
      const paEl = document.getElementById('_vp_d_pa');
      if (paEl) paEl.textContent = fixVietnamese(res?.pa || '—');
    });
    // Nếu viet trống → tra VP/Names (rồi mới PA) để tự điền
    if (!currentViet) {
      runtimeSendMessage({ action: 'getTranslation', han: hanText }, res => {
        const vEl = document.getElementById('_vp_d_viet');
        if (vEl && res?.viet && !vEl.value.trim()) vEl.value = fixVietnamese(res.viet);
      });
    }
  } else {
    const paEl = document.getElementById('_vp_d_pa');
    if (paEl) paEl.textContent = '—';
  }

  const back = document.createElement('div');
  back.id = '_vp_edit_backdrop';
  Object.assign(back.style, {
    position:'fixed', inset:'0', zIndex:'2147483645',
    background:'rgba(0,0,0,0.45)', backdropFilter:'blur(2px)'
  });
  back.onclick = () => { dial.remove(); back.remove(); };
  document.body.appendChild(back);

  const hanEl  = document.getElementById('_vp_d_han');
  const vietEl = document.getElementById('_vp_d_viet');
  const msgEl  = document.getElementById('_vp_d_msg');
  const setMsg = (t, err) => { msgEl.textContent = t; msgEl.style.color = err ? 'var(--vp-red)' : 'var(--vp-green)'; };
  let _paReq = 0;
  const close  = () => { _paReq++; dial.remove(); back.remove(); };

  // ── Wire up case-transform buttons ───────────────────────
  let _activeCaseBtn = null;

  function applyCaseTransform(transformFn, btnEl) {
    const v = vietEl.value;
    if (!v.trim()) return;
    vietEl.value = transformFn(v);
    // Highlight active button
    if (_activeCaseBtn) _activeCaseBtn.removeAttribute('data-active');
    _activeCaseBtn = btnEl;
    btnEl.setAttribute('data-active', '1');
    // Style: active = blue filled
    [lower, first, second, all].forEach(b => {
      const isActive = b === btnEl;
      b.style.background = isActive ? 'var(--vp-blue-btn)' : 'var(--vp-bg2)';
      b.style.color      = isActive ? '#fff' : 'var(--vp-text2)';
      b.style.borderColor = isActive ? 'var(--vp-blue-btn)' : 'var(--vp-border)';
    });
    vietEl.focus();
  }

  const lower  = document.getElementById('_vp_c_lower');
  const first  = document.getElementById('_vp_c_first');
  const second = document.getElementById('_vp_c_second');
  const all    = document.getElementById('_vp_c_all');

  lower .onclick = () => applyCaseTransform(caseTransforms.lower,       lower);
  first .onclick = () => applyCaseTransform(caseTransforms.titleFirst,  first);
  second.onclick = () => applyCaseTransform(caseTransforms.titleSecond, second);
  all   .onclick = () => applyCaseTransform(caseTransforms.titleAll,    all);

  // Auto-detect current case and highlight matching button on open
  function detectCurrentCase(s) {
    if (!s || !s.trim()) return null;
    const words = s.trim().split(' ');
    const isCapWord = w => w && [...w][0] === [...w][0].toUpperCase() && [...w][0] !== [...w][0].toLowerCase();
    const allLower = words.every(w => !isCapWord(w));
    if (allLower) return lower;
    const allCapped = words.length > 1 && words.every(isCapWord);
    if (allCapped) return all;
    if (words.length >= 1 && isCapWord(words[0]) && (words.length < 2 || !isCapWord(words[1]))) return first;
    if (words.length >= 2 && !isCapWord(words[0]) && isCapWord(words[1])) return second;
    return null;
  }
  const detected = detectCurrentCase(currentViet);
  if (detected) applyCaseTransform(v => v, detected); // highlight only, no transform

  // ── Cập nhật phiên âm và nghĩa khi user thay đổi chữ Hán ─
  let _paTimer = null;
  hanEl.addEventListener('input', () => {
    const han = hanEl.value.trim();
    const paEl = document.getElementById('_vp_d_pa');
    if (!paEl) return;
    if (!han || !CJK_RE.test(han)) { paEl.textContent = '—'; return; }
    clearTimeout(_paTimer);
    const myReq = ++_paReq;
    _paTimer = setTimeout(() => {
      runtimeSendMessage({ action: 'getPA', han }, res => {
        if (_paReq !== myReq) return; // response lỗi thời, bỏ qua
        const el = document.getElementById('_vp_d_pa');
        if (el) el.textContent = fixVietnamese(res?.pa || '—');
      });
      // Auto-điền nghĩa từ VP/Names nếu viet đang trống
      if (!vietEl.value.trim()) {
        runtimeSendMessage({ action: 'getTranslation', han }, res => {
          if (_paReq !== myReq) return;
          const el = document.getElementById('_vp_d_viet');
          if (el && res?.viet && !el.value.trim()) el.value = fixVietnamese(res.viet);
        });
      }
    }, 150);
  });

  // ── Reset highlight khi user tự gõ ───────────────────────
  vietEl.addEventListener('input', () => {
    if (_activeCaseBtn) {
      _activeCaseBtn = null;
      [lower, first, second, all].forEach(b => {
        b.style.background  = 'var(--vp-bg2)';
        b.style.color       = 'var(--vp-text2)';
        b.style.borderColor = 'var(--vp-border)';
      });
    }
  });

  document.getElementById('_vp_d_cancel').onclick = close;
  document.getElementById('_vp_d_save').onclick = () => {
    const han = fixVietnamese(hanEl.value).trim(), viet = fixVietnamese(vietEl.value).trim();
    if (!han)  { setMsg('Vui lòng nhập chữ Hán', true); return; }
    if (!viet) { setMsg('Vui lòng nhập nghĩa tiếng Việt', true); return; }
    setMsg('Đang lưu...');
    runtimeSendMessage({ action: 'editEntry', dict: type, han, viet }, res => {
      if (res?.success) {
        setMsg('Đã lưu! Đang làm mới...');
        runtimeSendMessage({ action: 'reloadDicts' }, () => {
          setTimeout(() => { close(); restoreAndRetranslate(); }, 700);
        });
      }
      else setMsg('Lỗi: ' + (res?.error || 'unknown'), true);
    });
  };
  document.getElementById('_vp_d_del').onclick = () => {
    const han = hanEl.value.trim();
    if (!han) { setMsg('Không có từ để xóa', true); return; }
    if (!confirm(`Xóa "${han}" khỏi từ điển?`)) return;
    runtimeSendMessage({ action: 'deleteEntry', dict: type, han }, res => {
      if (res?.success) {
        setMsg('Đã xóa! Đang làm mới...');
        runtimeSendMessage({ action: 'reloadDicts' }, () => {
          setTimeout(() => { close(); restoreAndRetranslate(); }, 700);
        });
      }
      else setMsg('Lỗi: ' + (res?.error || 'unknown'), true);
    });
  };
  const onEsc = e => { if (e.key === 'Escape') { close(); document.removeEventListener('keydown', onEsc); } };
  document.addEventListener('keydown', onEsc);
  vietEl.addEventListener('keydown', e => { if (e.key === 'Enter') document.getElementById('_vp_d_save').click(); });
  vietEl.focus(); vietEl.select();
}

// ═══════════════════════════════════════════════════════
// Floating Panel — nút nằm ngang, thu/mở khi hover
// ═══════════════════════════════════════════════════════
let _floatPanel = null;
let _panelCollapsed = true;

function mdIcon(name) {
  const paths = {
    play:        '<path d="M8 5v14l11-7z"/>',
    refresh:     '<path d="M17.65 6.35A7.95 7.95 0 0 0 12 4V1L7 6l5 5V7a5 5 0 1 1-5 5H5a7 7 0 1 0 12.65-5.65"/>',
    edit:        '<path d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75zm17.71-10.04a1.003 1.003 0 0 0 0-1.42L18.21 3.29a1.003 1.003 0 0 0-1.42 0l-1.96 1.96 3.75 3.75z"/>',
    book:        '<path d="M18 2H8a3 3 0 0 0-3 3v14a3 3 0 0 1 3-3h10a2 2 0 0 1 2 2V4a2 2 0 0 0-2-2m0 12H8a4.98 4.98 0 0 0-1 .1V5a1 1 0 0 1 1-1h10z"/>',
    progress:    '<path d="M12 2a10 10 0 1 0 10 10h-2a8 8 0 1 1-8-8z"/>',
    done:        '<path d="M9 16.17 4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/>',
    settings:    '<path d="M19.14 12.94c.04-.3.06-.61.06-.94 0-.32-.02-.64-.07-.94l2.03-1.58a.49.49 0 0 0 .12-.61l-1.92-3.32a.49.49 0 0 0-.59-.22l-2.39.96c-.5-.38-1.03-.7-1.62-.94l-.36-2.54a.484.484 0 0 0-.48-.41H9.84c-.24 0-.43.17-.47.41l-.36 2.54c-.59.24-1.13.57-1.62.94l-2.39-.96a.49.49 0 0 0-.59.22L2.49 9.87a.49.49 0 0 0 .12.61l2.03 1.58c-.05.3-.09.63-.09.94s.02.64.07.94l-2.03 1.58a.49.49 0 0 0-.12.61l1.92 3.32c.12.22.37.29.59.22l2.39-.96c.5.38 1.03.7 1.62.94l.36 2.54c.05.24.24.41.48.41h3.84c.24 0 .44-.17.47-.41l.36-2.54c.59-.24 1.13-.56 1.62-.94l2.39.96c.22.08.47 0 .59-.22l1.92-3.32a.49.49 0 0 0-.12-.61zM12 15.6c-1.98 0-3.6-1.62-3.6-3.6s1.62-3.6 3.6-3.6 3.6 1.62 3.6 3.6-1.62 3.6-3.6 3.6z"/>',
    toggleOn:    '<path d="M7 7h10a5 5 0 0 1 0 10H7A5 5 0 0 1 7 7m10 8a3 3 0 0 0 0-6H7a3 3 0 0 0 0 6zm0-1.5A2.5 2.5 0 1 0 17 8.5a2.5 2.5 0 0 0 0 5"/>',
    toggleOff:   '<path d="M7 7h10a5 5 0 0 1 0 10H7A5 5 0 0 1 7 7m0 2a3 3 0 0 0 0 6h10a3 3 0 0 0 0-6zm0 4.5A2.5 2.5 0 1 1 7 8.5a2.5 2.5 0 0 1 0 5"/>',
    collapse:    '<path d="M19 13H5v-2h14z"/>',
    expand:      '<path d="M4 6h16v2H4zm0 5h16v2H4zm0 5h16v2H4z"/>'
  };
  return `<svg class="mi" viewBox="0 0 24 24" aria-hidden="true">${paths[name] || ''}</svg>`;
}

function mkBtn(icon, label, cls, title) {
  const btn = document.createElement('button');
  btn.className = 'vp-fpanel-btn' + (cls ? ' ' + cls : '');
  btn.title = title || label;
  btn.innerHTML = `<span class="fp-icon">${icon}</span><span class="fp-label">${label}</span>`;
  return btn;
}

function buildFloatPanel() {
  if (!_floatPanel || !document.getElementById('_vp_float_panel')) {
    injectThemeStyle();
    _floatPanel = document.createElement('div');
    _floatPanel.id = '_vp_float_panel';
    _floatPanel.className = '_vp_ui' + (_isTouchDevice ? ' vp-touch' : '');
    document.body.appendChild(_floatPanel);
  }
  _floatPanel.innerHTML = '';
  _floatPanel.classList.toggle('vp-expanded', !_panelCollapsed);
  _floatPanel.classList.toggle('vp-collapsed', _panelCollapsed);

  // 1. Dịch
  const btnTrans = mkBtn(mdIcon('play'), 'Dịch VP', '', 'Dịch trang ngay');
  let _transBusy = false;
  btnTrans.onclick = async () => {
    if (_transBusy) return;
    _transBusy = true;
    btnTrans.querySelector('.fp-icon').innerHTML = mdIcon('progress');
    await realtimeTranslate(true);
    btnTrans.querySelector('.fp-icon').innerHTML = mdIcon('done');
    setTimeout(() => {
      _transBusy = false;
      btnTrans.querySelector('.fp-icon').innerHTML = mdIcon('play');
    }, 1800);
  };
  _floatPanel.appendChild(btnTrans);

  // 2. Làm mới
  const btnReload = mkBtn(mdIcon('refresh'), 'Làm mới', 'green', 'Làm mới bản dịch');
  btnReload.onclick = () => {
    btnReload.querySelector('.fp-icon').innerHTML = mdIcon('progress');
    reloadDictsAndRetranslate();
    setTimeout(() => { btnReload.querySelector('.fp-icon').innerHTML = mdIcon('refresh'); }, 1200);
  };
  _floatPanel.appendChild(btnReload);

  // 3. Sửa VP
  const btnEditVP = mkBtn(mdIcon('edit'), 'Sửa VP', 'orange', 'Sửa Vietphrase cho từ đang chọn');
  btnEditVP.onclick = () => {
    const openVP = () => {
      const data = _lastSelectionData || extractSelectionData();
      openEditDialog('VP', data?.han || '', data?.viet || '');
    };
    if (_lastSelectionData?._pending && !_lastSelectionData?._resolved) {
      setTimeout(openVP, 400);
    } else {
      openVP();
    }
  };
  _floatPanel.appendChild(btnEditVP);

  // 4. Sửa Name
  const btnEditN = mkBtn(mdIcon('edit'), 'Sửa Name', 'purple', 'Sửa tên riêng cho từ đang chọn');
  btnEditN.onclick = () => {
    const openName = () => {
      const data = _lastSelectionData || extractSelectionData();
      openEditDialog('Names', data?.han || '', data?.viet || '');
    };
    if (_lastSelectionData?._pending && !_lastSelectionData?._resolved) {
      setTimeout(openName, 400);
    } else {
      openName();
    }
  };
  _floatPanel.appendChild(btnEditN);

  // 5. Editor
  const btnEditor = mkBtn(mdIcon('book'), 'Edit Dict', 'indigo', 'Mở Editor từ điển');
  btnEditor.onclick = () => runtimeSendMessage({ action: 'openEditor' });
  _floatPanel.appendChild(btnEditor);

  // 5b. Cài đặt — chỉ hiện trên mobile (desktop dùng popup)
  if (_isTouchDevice) {
    const btnSettings = mkBtn(mdIcon('settings'), 'Cài đặt', '', 'Mở trang cài đặt');
    btnSettings.onclick = () => runtimeSendMessage({ action: 'openSettings' });
    _floatPanel.appendChild(btnSettings);
  }

  // 5c. Thu/mở panel — collapsed chỉ còn một nút toggle
  const btnCollapse = mkBtn(
    _panelCollapsed ? mdIcon('expand') : mdIcon('collapse'),
    _panelCollapsed ? 'Mở rộng' : 'Thu gọn',
    '',
    _panelCollapsed ? 'Mở rộng panel' : 'Thu gọn panel'
  );
  btnCollapse.classList.add('vp-panel-toggle');
  btnCollapse.onclick = () => {
    _panelCollapsed = !_panelCollapsed;
    void storageSet('local', { vpPanelCollapsed: _panelCollapsed });
    _floatPanel.classList.toggle('vp-expanded', !_panelCollapsed);
    _floatPanel.classList.toggle('vp-collapsed', _panelCollapsed);
    btnCollapse.title = _panelCollapsed ? 'Mở rộng panel' : 'Thu gọn panel';
    btnCollapse.querySelector('.fp-icon').innerHTML = _panelCollapsed ? mdIcon('expand') : mdIcon('collapse');
    btnCollapse.querySelector('.fp-label').textContent = _panelCollapsed ? 'Mở rộng' : 'Thu gọn';
  };
  _floatPanel.appendChild(btnCollapse);

  // 6. Auto on/off
  const isOn = settings.enable;
  const btnToggle = mkBtn(isOn ? mdIcon('toggleOn') : mdIcon('toggleOff'), isOn ? 'Auto ON' : 'Auto OFF', isOn ? 'green' : 'off',
    isOn ? 'Tắt dịch tự động' : 'Bật dịch tự động');
  btnToggle.onclick = async () => {
    settings.enable = !settings.enable;
    const opts = await new Promise(r => runtimeSendMessage({ action: 'getOptions' }, r));
    await new Promise(r => runtimeSendMessage({ action: 'setOptions', options: { ...opts, enable: settings.enable } }, r));
    buildFloatPanel();
    if (settings.enable) realtimeTranslate(true);
  };
  _floatPanel.appendChild(btnToggle);
}

// ═══════════════════════════════════════════════════════
// Message listener
// ═══════════════════════════════════════════════════════
ext.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  switch (msg.action) {
    case 'copyOriginal': {
      if (_lastSelectionData?._pending && !_lastSelectionData?._resolved) {
        setTimeout(() => { copyOriginal(); sendResponse({ ok: true }); }, 400);
        return true; // giữ channel cho async response
      }
      copyOriginal(); sendResponse({ ok: true }); break;
    }

    case 'openEditDialog': {
      // Nếu đang pending (reverseTranslate chưa xong), đợi tối đa 300ms
      const openWithData = () => {
        const data = _lastSelectionData;
        let han  = data?.han  || '';
        let viet = data?.viet || '';
        // Safety: nếu han là cả đoạn (>12 ký tự CJK) → xóa, không hiện full paragraph
        const cjk = (han.match(/[\u4e00-\u9fff\u3400-\u4dbf]/g) || []).length;
        if (cjk > 12) { han = ''; viet = ''; }  // full paragraph → clear
        if (han && cjk === 0) { han = ''; }       // Latin in han field → clear
        if (!han && msg.selText) {
          const t = msg.selText.trim();
          if (/[\u4e00-\u9fff\u3400-\u4dbf]/.test(t)) han = t; // only CJK selText → han
        }
        openEditDialog(msg.type, han, viet);
      };

      if (_lastSelectionData?._pending && !_lastSelectionData?._resolved) {
        // Chờ reverseTranslate callback (max 400ms)
        setTimeout(openWithData, 400);
      } else {
        openWithData();
      }
      sendResponse({ ok: true }); break;
    }

    case 'updateSettings': {
      Object.assign(settings, msg.options);
      deferDelay     = settings.delayMutation ?? 200;
      translateDelay = settings.delayTrans    ?? 120;
      // Restart observer with new delay if enablescript changed
      if (observer) { observer.disconnect(); observer = null; }
      if (settings.enablescript && !firstTrans) startObserver();
      // Attach ajax if newly enabled
      if (settings.enableajax) attachAjaxInterceptor();
      buildFloatPanel();
      sendResponse({ ok: true }); break;
    }

    case 'restoreAndRetranslate':
      reloadDictsAndRetranslate(() => sendResponse({ ok: true }));
      return true;

    case 'enableAutoTranslate':
      settings.enable = true; buildFloatPanel(); realtimeTranslate(true);
      sendResponse({ ok: true }); break;

    case 'disableAutoTranslate':
      settings.enable = false; buildFloatPanel();
      sendResponse({ ok: true }); break;
  }
  return true;
});

// ═══════════════════════════════════════════════════════
function checkOverflow(el, stl) {
  stl = stl || getComputedStyle(el);
  const ov = stl.overflow;
  if (ov === 'auto' || ov === 'hidden') return false;
  return el.clientWidth < el.scrollWidth || el.clientHeight < el.scrollHeight;
}

function removeOverflow(nodes = null) {
  if (!settings.heightauto && !settings.widthauto && !settings.scaleauto) return;

  const targets = new Set();
  if (nodes) {
    for (const n of nodes) {
      let cur = n.parentElement;
      while (cur && cur !== document.body && !cur.hasAttribute('_vp_calc')) {
        const tag = cur.tagName;
        if (tag === 'DIV' || tag === 'NAV' || tag === 'MAIN' || tag === 'SECTION' || tag === 'ARTICLE') {
          targets.add(cur);
        }
        cur = cur.parentElement;
      }
    }
  } else {
    document.querySelectorAll('div:not([_vp_calc]),nav,main,section,article').forEach(e => targets.add(e));
  }

  targets.forEach(e => {
    e.setAttribute('_vp_calc', '1');
    const stl = getComputedStyle(e);
    if (!checkOverflow(e, stl)) return;

    if (settings.heightauto) {
      if (stl.maxHeight === 'none')
        e.style.maxHeight = (parseInt(stl.height) * 2) + 'px';
      if (parseInt(stl.height) + 'px' === stl.height)
        e.style.minHeight = stl.height;
      if (stl.overflowY !== 'auto' && stl.overflowY !== 'scroll')
        e.style.height = 'auto';
    }
    if (settings.widthauto) {
      if (parseInt(stl.width) + 'px' === stl.width)
        e.style.minWidth = stl.width;
      e.style.width = 'auto';
    }
  });

  if (settings.scaleauto) {
    const sel = 'a:not([_vp_calc]),button:not([_vp_calc]),span:not([_vp_calc]),' +
                'li:not([_vp_calc]),h1:not([_vp_calc]),h2:not([_vp_calc]),' +
                'h3:not([_vp_calc]),h4:not([_vp_calc]),label:not([_vp_calc])';
    document.querySelectorAll(sel).forEach(e => {
      e.setAttribute('_vp_calc', '1');
      if (!checkOverflow(e)) return;
      const stl = getComputedStyle(e);
      let fontsize = parseInt(stl.fontSize);
      if (!fontsize || fontsize <= 10) return;
      let multiply = 1;
      if (fontsize > 26) multiply = 4;
      else if (fontsize > 22) multiply = 3;
      else if (fontsize >= 16) multiply = 2;
      const newSize = Math.max(10, fontsize - multiply);
      e.style.fontSize = newSize + 'px';
      if (checkOverflow(e)) {
        const newSize2 = Math.max(10, fontsize - multiply * 2);
        e.style.fontSize = newSize2 + 'px';
      }
    });
  }
}

let _ajaxAttached = false;
function attachAjaxInterceptor() {
  if (_ajaxAttached || !settings.enableajax) return;
  _ajaxAttached = true;

  // Inject vào page context qua script tag
  const script = document.createElement('script');
  script.textContent = `
    (function() {
      if (window._vpAjaxHooked) return;
      window._vpAjaxHooked = true;
      var origSend = XMLHttpRequest.prototype.send;
      XMLHttpRequest.prototype.send = function() {
        this.addEventListener('loadend', function() {
          if (this.responseText && this.responseText.length > 10) {
            document.dispatchEvent(new CustomEvent('_vp_ajax_done'));
          }
        });
        origSend.apply(this, arguments);
      };
      // Also intercept fetch
      var origFetch = window.fetch;
      window.fetch = function() {
        return origFetch.apply(this, arguments).then(function(r) {
          document.dispatchEvent(new CustomEvent('_vp_ajax_done'));
          return r;
        });
      };
    })();
  `;
  (document.head || document.documentElement).appendChild(script);
  script.remove();

  // Listen for the custom event from page context
  let _ajaxTimer = null;
  document.addEventListener('_vp_ajax_done', () => {
    clearTimeout(_ajaxTimer);
    _ajaxTimer = setTimeout(() => realtimeTranslate(), translateDelay);
  });
}

// ═══════════════════════════════════════════════════════
// Init
// ═══════════════════════════════════════════════════════
(async function init() {
  const r = await storageGet('sync', 'vpOptions');
  if (r.vpOptions) {
    Object.assign(settings, r.vpOptions);
    // Sync delay vars
    deferDelay    = settings.delayMutation ?? 200;
    translateDelay = settings.delayTrans   ?? 120;
  }

  const lc = await storageGet('local', 'vpPanelCollapsed');
  if (lc.vpPanelCollapsed !== undefined) _panelCollapsed = lc.vpPanelCollapsed;

  if (document.body) buildFloatPanel();
  else document.addEventListener('DOMContentLoaded', buildFloatPanel);

  if (settings.enable) {
    setTimeout(() => realtimeTranslate(), translateDelay);
  }

  // AJAX intercept
  if (settings.enableajax) attachAjaxInterceptor();
})();
